from deepeval.tracing.otel.exporter import ConfidentSpanExporter
from tests.test_integrations.test_exporter.readable_spans import (
    list_of_readable_spans,
    llm_span_list,
    multi_turn_span_list,
)
from deepeval.tracing.trace_test_manager import trace_testing_manager

exporter = ConfidentSpanExporter()


async def test_pydantic_ai_trace():
    try:
        trace_testing_manager.test_name = "any_name"
        exporter.export(list_of_readable_spans)
        actual_dict = await trace_testing_manager.wait_for_test_dict()

        # Assert that System Instruction is the first input message
        assert (
            actual_dict["input"][0]["role"] == "System Instruction"
        ), f"Expected first input role to be 'System Instruction', got {actual_dict['input'][0]['role']}"

        # Assert that output is the last non-thinking part (the final text content)
        assert (
            actual_dict["output"]["content"] == "Final response text"
        ), f"Expected output content to be 'Final response text', got {actual_dict['output']['content']}"

    finally:
        trace_testing_manager.test_name = None
        trace_testing_manager.test_dict = None


async def test_multi_turn_trace():
    try:
        trace_testing_manager.test_name = "any_name"
        exporter.export(multi_turn_span_list)
        actual_dict = await trace_testing_manager.wait_for_test_dict()

        # Assert that the trace input is the last user text message
        assert (
            actual_dict["input"][0]["role"] == "System Instruction"
        ), f"Expected first input role to be 'System Instruction', got {actual_dict['input'][0]['role']}"

        assert (
            actual_dict["input"][1]["content"]
            == "What are the columns in the report?"
        ), f"Expected input to be the follow-up question, got {actual_dict['input'][1]['content']}"

        # Assert that the output is the final result
        assert (
            actual_dict["output"] == "The report contains 68 columns."
        ), f"Expected output to be final result, got {actual_dict['output']}"

    finally:
        trace_testing_manager.test_name = None
        trace_testing_manager.test_dict = None


async def test_llm_trace():
    try:
        trace_testing_manager.test_name = "any_name"
        exporter.export(llm_span_list)
        actual_dict = await trace_testing_manager.wait_for_test_dict()

        assert (
            actual_dict["llmSpans"][0]["input"][-1]["role"]
            == "Model Request Parameters"
        ), f"Expected input role to be 'Model Request Parameters', got {actual_dict['llmSpans'][0]['input'][-1]['role']}"

        assert (
            actual_dict["llmSpans"][0]["inputTokenCount"] == 1000
        ), f"Expected input token count to be 1000, got {actual_dict['llmSpans'][0]['inputTokenCount']}"
        assert (
            actual_dict["llmSpans"][0]["outputTokenCount"] == 500
        ), f"Expected output token count to be 500, got {actual_dict['llmSpans'][0]['outputTokenCount']}"

    finally:
        trace_testing_manager.test_name = None
        trace_testing_manager.test_dict = None


async def test_pydantic_ai_tools_called():
    try:
        trace_testing_manager.test_name = "any_name"
        exporter.export(list_of_readable_spans)
        actual_dict = await trace_testing_manager.wait_for_test_dict()

        tools_called = actual_dict["agentSpans"][0]["toolsCalled"]
        assert (
            len(tools_called) == 1
        ), f"Expected 1 tool call, got {len(tools_called)}"
        assert (
            tools_called[0]["name"] == "test_tool"
        ), f"Expected tool name 'test_tool', got {tools_called[0]['name']}"
        assert tools_called[0]["inputParameters"] == {
            "query": "test query"
        }, f"Expected inputParameters, got {tools_called[0]['inputParameters']}"
        assert (
            tools_called[0]["output"] == "Test tool result"
        ), f"Expected output 'Test tool result', got {tools_called[0]['output']}"

    finally:
        trace_testing_manager.test_name = None
        trace_testing_manager.test_dict = None
