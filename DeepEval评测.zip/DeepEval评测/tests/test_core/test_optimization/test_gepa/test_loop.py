import pytest

from tests.test_core.stubs import (
    StubScoringAdapter,
    SuffixRewriter,
    _DummyRewriter,
)
from deepeval.errors import DeepEvalError
from deepeval.optimizer.algorithms import GEPA
from deepeval.optimizer.types import (
    AcceptedIteration,
    OptimizationReport,
    PromptConfiguration,
    RunnerStatusType,
)
from deepeval.prompt.prompt import Prompt

##########################
# execute / a_execute    #
##########################


def test_execute_requires_at_least_two_goldens() -> None:
    runner = GEPA(
        iterations=1,
        minibatch_size=1,
        pareto_size=1,
        scorer=StubScoringAdapter(),
    )
    prompt = Prompt(text_template="base")

    with pytest.raises(DeepEvalError, match="requires at least 2 goldens"):
        runner.execute(prompt=prompt, goldens=[object()])


@pytest.mark.asyncio
async def test_a_execute_requires_at_least_two_goldens() -> None:
    runner = GEPA(
        iterations=1,
        minibatch_size=1,
        pareto_size=1,
        scorer=StubScoringAdapter(),
    )
    prompt = Prompt(text_template="base")

    with pytest.raises(DeepEvalError, match="requires at least 2 goldens"):
        await runner.a_execute(prompt=prompt, goldens=[object()])


def test_execute_raises_without_scorer() -> None:
    runner = GEPA(iterations=1, minibatch_size=1, pareto_size=1, scorer=None)
    prompt = Prompt(text_template="base")
    goldens = [object(), object()]

    with pytest.raises((DeepEvalError, AttributeError)):
        runner.execute(prompt=prompt, goldens=goldens)


def test_execute_end_to_end_accepts_improved_child_prompt() -> None:
    """
    Full GEPA run with a stub scoring adapter and rewriter:

    - root prompt scores lower on Pareto than the child
    - child is accepted
    - the returned best prompt is the rewritten child
    """
    scoring = StubScoringAdapter()
    runner = GEPA(
        iterations=1,
        minibatch_size=1,
        pareto_size=1,
        random_seed=0,
        scorer=scoring,
    )

    # Use a deterministic rewriter that always improves the text.
    runner._rewriter = SuffixRewriter(" CHILD")

    prompt = Prompt(text_template="base")
    goldens = [object(), object()]

    best_prompt, report = runner.execute(prompt=prompt, goldens=goldens)

    assert isinstance(best_prompt, Prompt)
    assert best_prompt.text_template == "base CHILD"

    # Report should be an OptimizationReport
    assert isinstance(report, OptimizationReport)

    # Reasonable sanity checks on the report payload
    assert report.optimization_id is not None
    assert report.best_id is not None
    assert report.accepted_iterations is not None
    assert report.pareto_scores is not None
    assert report.parents is not None
    assert report.prompt_configurations is not None

    assert len(report.accepted_iterations) == 1

    # prompt_configurations should contain at least the best config id
    prompt_cfgs = report.prompt_configurations
    assert isinstance(prompt_cfgs, dict)
    assert report.best_id in prompt_cfgs


@pytest.mark.asyncio
async def test_a_execute_end_to_end_accepts_improved_child_prompt() -> None:
    """
    Async variant of the full GEPA run using the same stubs.
    """
    scoring = StubScoringAdapter()
    runner = GEPA(
        iterations=1,
        minibatch_size=1,
        pareto_size=1,
        random_seed=0,
        scorer=scoring,
    )
    runner._rewriter = SuffixRewriter(" CHILD")

    prompt = Prompt(text_template="base")
    goldens = [object(), object()]

    best_prompt, report = await runner.a_execute(prompt=prompt, goldens=goldens)

    assert isinstance(best_prompt, Prompt)
    assert best_prompt.text_template == "base CHILD"

    assert isinstance(report, OptimizationReport)
    assert report.optimization_id is not None
    assert report.best_id is not None
    assert report.accepted_iterations is not None
    assert report.pareto_scores is not None
    assert report.parents is not None
    assert report.prompt_configurations is not None

    prompt_cfgs = report.prompt_configurations
    assert isinstance(prompt_cfgs, dict)
    assert report.best_id in prompt_cfgs


##########################
# Minibatch / acceptance #
##########################


def test_draw_minibatch_respects_minibatch_size() -> None:
    runner = GEPA(
        iterations=1,
        minibatch_size=3,
        pareto_size=1,
        random_seed=0,
        scorer=StubScoringAdapter(),
    )
    d_feedback = list(range(10))

    batch = runner._draw_minibatch(d_feedback)

    assert len(batch) == 3
    assert all(item in d_feedback for item in batch)


def test_draw_minibatch_clamps_to_available_data() -> None:
    runner = GEPA(
        iterations=1,
        minibatch_size=10,
        pareto_size=1,
        random_seed=0,
        scorer=StubScoringAdapter(),
    )

    # With only 3 feedback items we should clamp to 3
    d_feedback_small = list(range(3))
    batch_small = runner._draw_minibatch(d_feedback_small)
    assert len(batch_small) == 3


def test_should_accept_child_respects_jitter() -> None:
    # Acceptance now uses non-domination against parent and archive vectors.
    runner = GEPA(scorer=StubScoringAdapter())
    runner.pareto_score_table = {"root": [0.5, 0.5]}

    # child dominated by parent -> reject
    assert runner._should_accept_child([0.4, 0.4], [0.5, 0.5]) is False
    # child non-dominated against parent/archive -> accept
    assert runner._should_accept_child([0.6, 0.4], [0.5, 0.5]) is True


######################################
# Rewriter integration / child build #
######################################


def _make_prompt_config(text: str) -> PromptConfiguration:
    return PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: Prompt(text_template=text)}
    )


def test_generate_child_prompt_returns_none_when_text_unchanged() -> None:
    runner = GEPA(scorer=StubScoringAdapter())
    parent = _make_prompt_config("  Hello ")
    runner._rewriter = _DummyRewriter()

    child = runner._generate_child_prompt(
        GEPA.SINGLE_MODULE_ID, parent, feedback_diagnosis="unused"
    )
    assert child is None


def test_generate_child_prompt_returns_new_prompt_when_text_changes() -> None:
    runner = GEPA(scorer=StubScoringAdapter())
    parent = _make_prompt_config("Hello")
    runner._rewriter = SuffixRewriter(" CHILD")

    child = runner._generate_child_prompt(
        GEPA.SINGLE_MODULE_ID, parent, feedback_diagnosis="unused"
    )
    assert isinstance(child, Prompt)
    assert child.text_template == "Hello CHILD"


@pytest.mark.asyncio
async def test_a_generate_child_prompt_async_mirrors_sync_behavior() -> None:
    runner = GEPA(scorer=StubScoringAdapter())
    parent = _make_prompt_config("Hello")
    runner._rewriter = SuffixRewriter(" CHILD")

    child = await runner._a_generate_child_prompt(
        GEPA.SINGLE_MODULE_ID, parent, feedback_diagnosis="unused"
    )
    assert isinstance(child, Prompt)
    assert child.text_template == "Hello CHILD"


def test_make_child_clones_parent_and_sets_parent_id() -> None:
    runner = GEPA(scorer=StubScoringAdapter())
    parent_prompt = Prompt(text_template="root")
    parent_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: parent_prompt}
    )

    child_prompt = Prompt(text_template="child")
    child_conf = runner._make_child(
        GEPA.SINGLE_MODULE_ID, parent_conf, child_prompt
    )

    assert child_conf.parent == parent_conf.id
    assert child_conf.prompts[GEPA.SINGLE_MODULE_ID] is child_prompt
    # Ensure parent prompt remains unchanged
    assert parent_conf.prompts[GEPA.SINGLE_MODULE_ID] is parent_prompt


def test_accept_child_updates_state_and_returns_accepted_iteration() -> None:
    runner = GEPA(scorer=StubScoringAdapter())

    parent_prompt = Prompt(text_template="root")
    child_prompt = Prompt(text_template="root CHILD")

    parent_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: parent_prompt}
    )
    runner._add_prompt_configuration(parent_conf)

    child_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: child_prompt},
        parent=parent_conf.id,
    )

    child_pareto_scores = [1.0, 1.0]
    runner.pareto_score_table[parent_conf.id] = [0.5, 0.5]

    accepted = runner._accept_child(
        GEPA.SINGLE_MODULE_ID,
        parent_conf,
        child_conf,
        child_pareto_scores,
        parent_agg_score=0.5,
        child_agg_score=1.0,
    )

    # Child must be registered with a Pareto score
    assert child_conf.id in runner.pareto_score_table
    assert isinstance(accepted, AcceptedIteration)
    assert accepted.parent == parent_conf.id
    assert accepted.child == child_conf.id
    assert accepted.module == GEPA.SINGLE_MODULE_ID
    assert accepted.before == pytest.approx(0.5)
    assert accepted.after == pytest.approx(1.0)


@pytest.mark.asyncio
async def test_a_accept_child_updates_state_and_returns_accepted_iteration() -> (
    None
):
    runner = GEPA(scorer=StubScoringAdapter())

    parent_prompt = Prompt(text_template="root")
    child_prompt = Prompt(text_template="root CHILD")

    parent_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: parent_prompt}
    )
    runner._add_prompt_configuration(parent_conf)

    child_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: child_prompt},
        parent=parent_conf.id,
    )

    child_pareto_scores = [1.0, 1.0]
    runner.pareto_score_table[parent_conf.id] = [0.5, 0.5]

    accepted = await runner._a_accept_child(
        GEPA.SINGLE_MODULE_ID,
        parent_conf,
        child_conf,
        child_pareto_scores,
        parent_agg_score=0.5,
        child_agg_score=1.0,
    )

    assert child_conf.id in runner.pareto_score_table
    assert isinstance(accepted, AcceptedIteration)
    assert accepted.parent == parent_conf.id
    assert accepted.child == child_conf.id


#####################################
# Aggregation / tie-breaker / loop  #
#####################################


def test_best_by_aggregate_prefers_child_and_emits_tie_status() -> None:
    """
    _best_by_aggregate should:
      - use the configured tie_breaker (default PREFER_CHILD)
      - emit a TIE status when multiple configs share the best total
    """
    runner = GEPA(scorer=StubScoringAdapter())

    root_prompt = Prompt(text_template="root")
    child_prompt = Prompt(text_template="root CHILD")

    root_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: root_prompt}
    )
    child_conf = PromptConfiguration.new(
        prompts={GEPA.SINGLE_MODULE_ID: child_prompt},
        parent=root_conf.id,
    )

    runner._add_prompt_configuration(root_conf)
    runner._add_prompt_configuration(child_conf)

    # Equal aggregate scores to force a tie
    runner.pareto_score_table = {
        root_conf.id: [1.0],
        child_conf.id: [1.0],
    }

    events = []

    def status_cb(kind, *, detail, step_index=None, total_steps=None):
        events.append((kind, detail, step_index, total_steps))

    runner.status_callback = status_cb

    best = runner._best_by_aggregate()

    # With PREFER_CHILD, the non root config should be chosen
    assert best.id == child_conf.id

    tie_events = [e for e in events if e[0] is RunnerStatusType.TIE]
    assert tie_events, "Expected at least one TIE status callback"
    tie_detail = tie_events[0][1]
    assert "tie on aggregate" in tie_detail
    assert "using tie_breaker='prefer_child'" in tie_detail


def test_run_loop_iteration_reports_progress_and_stops_on_false() -> None:
    """
    _run_loop_iteration should:
      - emit an initial PROGRESS event at iteration 0
      - emit PROGRESS per successful iteration
      - stop when the iteration callback returns False
    """
    runner = GEPA(iterations=3, scorer=StubScoringAdapter())

    events = []

    def status_cb(kind, *, detail, step_index=None, total_steps=None):
        events.append((kind, step_index, total_steps, detail))

    runner.status_callback = status_cb

    calls = {"count": 0}

    def gepa_iteration() -> bool:
        calls["count"] += 1
        # stop after the second call returns False
        return calls["count"] < 2

    runner._run_loop_iteration(gepa_iteration)

    # Initial progress event at step_index=0 plus one successful iteration.
    progress_events = [e for e in events if e[0] is RunnerStatusType.PROGRESS]
    assert len(progress_events) == 2
    # First call should be iteration 0
    assert progress_events[0][1] == 0
    assert progress_events[0][2] == runner.iterations


@pytest.mark.asyncio
async def test_a_run_loop_iteration_reports_error_and_stops() -> None:
    """
    _a_run_loop_iteration should:
      - emit initial PROGRESS
      - emit ERROR on exception
      - stop without propagating the exception
    """
    runner = GEPA(iterations=3, scorer=StubScoringAdapter())

    events = []

    def status_cb(kind, *, detail, step_index=None, total_steps=None):
        events.append((kind, step_index, total_steps, detail))

    runner.status_callback = status_cb

    async def failing_iteration() -> bool:
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        await runner._a_run_loop_iteration(failing_iteration)

    kinds = [e[0] for e in events]
    assert kinds[0] is RunnerStatusType.PROGRESS  # initial event
    assert any(k is RunnerStatusType.ERROR for k in kinds)
    error_events = [e for e in events if e[0] is RunnerStatusType.ERROR]
    assert "boom" in error_events[0][3]
