"""
本地 LLM 模型评测脚本（基于 Ollama + DeepEval）

使用前：
1. 确保 Ollama 已启动：ollama serve
2. 已拉取模型：ollama pull <model_name>
3. 安装依赖：pip install deepeval ollama
4. 运行：python evaluate_local_model.py
"""

from deepeval import evaluate
from deepeval.test_case import LLMTestCase
from deepeval.metrics import (
    AnswerRelevancyMetric,
    GEval,
    FaithfulnessMetric,
    ToxicityMetric,
    ContextualRecallMetric,
    ContextualPrecisionMetric,
)
from deepeval.models import OllamaModel
from deepeval.test_case import SingleTurnParams

# ============================================================
# 配置区：修改此处以适配你的本地模型
# ============================================================
OLLAMA_MODEL_NAME = "qwen2.5:7b"       # Ollama 模型名称
OLLAMA_BASE_URL = "http://localhost:11434"  # Ollama 服务地址
TEMPERATURE = 0.0

# 初始化 Ollama 模型（用于评分的 judge model）
# 注意：DeepEval 的指标需要一个 judge model 来打分
# 这里用 Ollama 本地模型同时作为被测模型和 judge 模型
judge_model = OllamaModel(
    model=OLLAMA_MODEL_NAME,
    base_url=OLLAMA_BASE_URL,
    temperature=TEMPERATURE,
)

# ============================================================
# 定义评测指标
# ============================================================
metrics = [
    AnswerRelevancyMetric(
        threshold=0.7,
        model=judge_model,
    ),
    GEval(
        name="Correctness",
        criteria="判断 actual_output 是否与 expected_output 语义一致，是否正确回答了问题。",
        evaluation_params=[
            SingleTurnParams.ACTUAL_OUTPUT,
            SingleTurnParams.EXPECTED_OUTPUT,
        ],
        threshold=0.7,
        model=judge_model,
    ),
    FaithfulnessMetric(
        threshold=0.7,
        model=judge_model,
    ),
    ToxicityMetric(
        threshold=0.5,
        model=judge_model,
    ),
    ContextualRecallMetric(
        threshold=0.7,
        model=judge_model,
    ),
    ContextualPrecisionMetric(
        threshold=0.7,
        model=judge_model,
    ),
]

# ============================================================
# 硬编码测试用例
# ============================================================
test_cases = [
    LLMTestCase(
        input="Python 中列表和元组有什么区别？",
        actual_output="列表是可变的，元组是不可变的。列表用方括号 [] 表示，元组用圆括号 () 表示。列表可以作为字典的键，元组不可以。",
        expected_output="列表是可变的，元组是不可变的。列表用方括号表示，元组用圆括号表示。由于元组不可变，所以元组可以作为字典的键，列表不可以。",
        retrieval_context=[
            "Python 中列表（list）是可变序列，元组（tuple）是不可变序列。",
            "列表使用方括号 []，元组使用圆括号 ()。",
            "不可变对象可以作为字典的键，可变对象不可以。",
        ],
        context=[
            "Python 基础数据结构包括列表、元组、字典和集合。",
            "列表是可变的，支持增删改操作；元组不可变，创建后不能修改。",
        ],
    ),
    LLMTestCase(
        input="什么是 RESTful API？",
        actual_output="RESTful API 是一种基于 HTTP 协议的接口设计风格，使用 GET、POST、PUT、DELETE 等方法操作资源，资源通过 URL 来标识。",
        expected_output="RESTful API 是一种遵循 REST 架构风格的 Web API 设计方式，它使用 HTTP 方法（GET/POST/PUT/DELETE）对资源进行 CRUD 操作，每个资源有唯一的 URL 标识。",
        retrieval_context=[
            "REST（Representational State Transfer）是一种软件架构风格。",
            "RESTful API 使用标准 HTTP 方法操作资源。",
            "资源通过 URI 进行标识，支持 JSON、XML 等格式。",
        ],
        context=[
            "Web API 有多种设计风格，其中 REST 是最流行的一种。",
            "REST 强调无状态、统一接口、资源导向等原则。",
        ],
    ),
    LLMTestCase(
        input="解释一下什么是过拟合？",
        actual_output="过拟合是指模型在训练数据上表现很好，但在新数据上表现很差，因为模型记住了训练数据的噪声和细节，而没有学到通用规律。",
        expected_output="过拟合是机器学习中模型过度拟合训练数据的现象，导致在训练集上误差很低，但在测试集上误差很高，泛化能力差。",
        retrieval_context=[
            "过拟合（Overfitting）发生在模型过于复杂时，模型会学习训练数据中的噪声。",
            "过拟合的表现是训练误差低但验证/测试误差高。",
            "常见的防止过拟合方法有正则化、Dropout、早停等。",
        ],
        context=[
            "机器学习模型需要在偏差和方差之间取得平衡。",
            "过拟合是高方差的表现，欠拟合是高偏差的表现。",
        ],
    ),
]

# ============================================================
# 运行评测
# ============================================================
if __name__ == "__main__":
    print(f"正在使用模型: {OLLAMA_MODEL_NAME}")
    print(f"Ollama 服务地址: {OLLAMA_BASE_URL}")
    print(f"测试用例数: {len(test_cases)}")
    print(f"评测指标数: {len(metrics)}")
    print("-" * 50)

    results = evaluate(
        test_cases=test_cases,
        metrics=metrics,
        run_async=False,
    )

    print("\n评测完成！")
