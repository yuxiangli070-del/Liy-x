from locust import HttpUser, task, between
import json


class DebugUser(HttpUser):
    wait_time = between(3, 5)
    
    @task
    def debug_session_list(self):
        """调试会话列表接口 - 打印完整请求响应信息"""
        
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
        
        url = "/prod-api/agent/ai/session/list"
        params = {"pageNum": 1, "pageSize": 20}
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        print("\n" + "="*80)
        print("🔍 调试请求信息")
        print("="*80)
        print(f"完整URL: {self.host}{url}")
        print(f"请求方法: GET")
        print(f"请求参数: {params}")
        print(f"请求头: {json.dumps(headers, indent=2, ensure_ascii=False)}")
        print("="*80)
        
        response = self.client.get(
            url, 
            params=params, 
            headers=headers, 
            catch_response=True,
            name="/prod-api/agent/ai/session/list"
        )
        
        print("\n" + "="*80)
        print("📊 调试响应信息")
        print("="*80)
        print(f"状态码: {response.status_code}")
        print(f"响应头: {dict(response.headers)}")
        print(f"Content-Type: {response.headers.get('Content-Type', 'Unknown')}")
        print(f"响应内容长度: {len(response.text)} 字符")
        print(f"\n响应内容（前500字符）:")
        print(response.text[:500])
        print("="*80)
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"\n✅ JSON解析成功:")
                print(f"  code: {data.get('code')}")
                print(f"  msg: {data.get('msg')}")
                if 'rows' in data:
                    print(f"  rows数量: {len(data.get('rows', []))}")
                    if data.get('rows'):
                        print(f"  第一条数据: {json.dumps(data['rows'][0], indent=2, ensure_ascii=False)[:200]}")
                response.success()
            except Exception as e:
                print(f"\n❌ JSON解析失败: {e}")
                print(f"响应内容类型可能是: {response.headers.get('Content-Type')}")
                response.failure(f"JSON解析失败: {e}")
        elif response.status_code == 401:
            print(f"\n❌ 401 未授权 - Token可能已失效！")
            print("请重新登录获取新Token")
            response.failure("Token失效")
        elif response.status_code == 403:
            print(f"\n❌ 403 禁止访问 - 权限不足")
            response.failure("权限不足")
        elif response.status_code == 404:
            print(f"\n❌ 404 未找到 - 接口路径错误")
            response.failure("路径错误")
        elif response.status_code == 405:
            print(f"\n❌ 405 方法不允许 - 接口不支持GET方法")
            response.failure("方法不允许")
        else:
            print(f"\n❌ 请求失败: {response.status_code}")
            response.failure(f"状态码: {response.status_code}")
    
    @task
    def debug_create_session(self):
        """调试创建会话接口"""
        
        import uuid
        from datetime import datetime
        
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
        
        url = "/prod-api/agent/ai/session"
        payload = {
            "sessionId": str(uuid.uuid4()),
            "title": f"调试会话-{datetime.now().strftime('%H%M%S')}",
            "userId": 1
        }
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        print("\n" + "="*80)
        print("🔍 调试创建会话请求")
        print("="*80)
        print(f"完整URL: {self.host}{url}")
        print(f"请求方法: POST")
        print(f"请求体: {json.dumps(payload, indent=2, ensure_ascii=False)}")
        print(f"请求头: {json.dumps(headers, indent=2, ensure_ascii=False)}")
        print("="*80)
        
        response = self.client.post(
            url,
            json=payload,
            headers=headers,
            catch_response=True,
            name="/prod-api/agent/ai/session"
        )
        
        print("\n" + "="*80)
        print("📊 调试创建会话响应")
        print("="*80)
        print(f"状态码: {response.status_code}")
        print(f"Content-Type: {response.headers.get('Content-Type', 'Unknown')}")
        print(f"响应内容（前500字符）:")
        print(response.text[:500])
        print("="*80)
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"\n✅ JSON解析成功:")
                print(f"  code: {data.get('code')}")
                print(f"  msg: {data.get('msg')}")
                response.success()
            except Exception as e:
                print(f"\n❌ JSON解析失败: {e}")
                response.failure(f"JSON解析失败: {e}")
        elif response.status_code == 401:
            print(f"\n❌ 401 未授权 - Token可能已失效！")
            response.failure("Token失效")
        elif response.status_code == 405:
            print(f"\n❌ 405 方法不允许")
            response.failure("方法不允许")
        else:
            print(f"\n❌ 请求失败: {response.status_code}")
            response.failure(f"状态码: {response.status_code}")
