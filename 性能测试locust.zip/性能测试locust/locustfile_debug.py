from locust import HttpUser, task, between
import json


class SimpleTestUser(HttpUser):
    wait_time = between(2, 3)
    
    @task
    def test_session_list(self):
        """只测试会话列表接口"""
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
        
        url = "/biwinAi/agent/ai/session/list"
        params = {"pageNum": 1, "pageSize": 20}
        headers = {"Authorization": f"Bearer {token}"}
        
        print(f"\n请求 URL: {self.host}{url}")
        print(f"请求参数: {params}")
        print(f"请求头: {headers}")
        
        response = self.client.get(url, params=params, headers=headers, catch_response=True)
        
        print(f"\n响应状态码: {response.status_code}")
        print(f"响应内容类型: {response.headers.get('Content-Type', 'Unknown')}")
        print(f"响应内容（前200字符）: {response.text[:200]}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"JSON 解析成功: code={data.get('code')}, msg={data.get('msg')}")
                response.success()
            except Exception as e:
                print(f"JSON 解析失败: {e}")
                response.failure(f"JSON解析失败: {e}")
        else:
            print(f"请求失败: {response.status_code}")
            response.failure(f"状态码: {response.status_code}")
