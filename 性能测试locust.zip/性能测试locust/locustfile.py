from locust import HttpUser, task, between
import csv
import random

# 1. 读取CSV参数文件（对应JMeter的CSV数据文件设置）
def load_test_data():
    data = []
    # 打开你刚才创建的CSV文件
    with open("test_data.csv", "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)  # 按表头读取，自动对应fileIds和handler
        for row in reader:
            data.append(row)
    return data

# 加载所有测试数据
test_data = load_test_data()

# 2. 定义压测用户
class AuditRetryUser(HttpUser):
    # 对应JMeter的线程组：请求之间的等待时间（1-3秒，模拟真实用户）
    wait_time = between(1, 3)
    
    # 3. 每个用户启动时，随机取一组CSV数据（对应JMeter的参数化）
    def on_start(self):
        # 从CSV数据里随机选一行，避免所有用户用同一组数据
        self.data = random.choice(test_data)

    # 4. 压测任务：1:1还原你的JMeter POST请求
    @task
    def audit_retry(self):
        # 构造请求体，完全对应你JMeter的Body Data
        payload = {
            "fileIds": [self.data["fileIds"]],  # 数组格式，和JMeter一致
            "handler": self.data["handler"]
        }

        # 发送POST请求，完全匹配你的接口配置
        self.client.post(
            url="/prod-api/api/file/audit/retry",  # 接口路径
            json=payload,  # JSON格式请求体，对应JMeter的Body Data
            # 自动开启KeepAlive，和JMeter的Use KeepAlive一致
            # 自动跟随重定向，和JMeter的Follow Redirects一致
        )