from locust import HttpUser, task, between
import json
import uuid
from datetime import datetime


class ChatWithSearchTestUser(HttpUser):
    wait_time = between(3, 5)
    
    @task
    def test_chat_with_search(self):
        """测试开启联网检索的对话接口"""
        
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiNmUyMDZmNTItNGQ2My00ODI0LThlNDQtYTk1Zjc2ZjY5YWJhIiwidXNlcm5hbWUiOiJTWjAxNTkifQ.iBor-YnOCueVaq0m309g1x14_N9UbYbQ6A2_A7g08fg8DrUS528Bd3FGEc07C-dPKowSBS-tuboZdOnjrnmSMA"
        
        url = "/prod-api/agent/chat/agui/run"
        
        thread_id = str(uuid.uuid4())
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')
        run_id = f"run-{timestamp}-{uuid.uuid4().hex[:8]}"
        message_id = f"msg-{uuid.uuid4().hex[:12]}"
        
        # 构造触发联网检索的提问
        payload = {
            "threadId": thread_id,
            "runId": run_id,
            "messages": [
                {
                    "id": message_id,
                    "role": "user",
                    "content": "请帮我查询一下今天最新的科技新闻和股市行情"
                }
            ],
            "forwardedProps": {
                "mode": "chat",
                "thinkingEnabled": False,
                "searchEnabled": True,  # 开启联网检索
                "stream": True,
                "attachments": []
            }
        }
        
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream"
        }
        
        max_retries = 2
        retry_count = 0
        success = False
        
        while retry_count <= max_retries and not success:
            if retry_count > 0:
                print(f"\n🔄 第 {retry_count} 次重试...")
            
            try:
                with self.client.post(
                    url,
                    json=payload,
                    headers=headers,
                    catch_response=True,
                    stream=True,
                    timeout=(15, 120),  # 联网检索可能较慢，放宽超时
                    name="开启联网检索对话"
                ) as response:
                    
                    if retry_count == 0:
                        print(f"\n状态码: {response.status_code}")
                        print(f"Content-Type: {response.headers.get('Content-Type', 'Unknown')}")
                        print(f"联网检索: 开启")
                    
                    if response.status_code == 200:
                        event_count = 0
                        full_response = ""
                        start_time = datetime.now()
                        
                        try:
                            for line in response.iter_lines():
                                elapsed = (datetime.now() - start_time).total_seconds()
                                if elapsed > 90:  # 90秒读取限制
                                    print(f"\n⏱️  读取超时: 已等待 {elapsed:.1f} 秒")
                                    break
                                
                                if line:
                                    decoded_line = line.decode('utf-8')
                                    full_response += decoded_line + "\n"
                                    if decoded_line.startswith('data:'):
                                        event_count += 1
                        except Exception as e:
                            if retry_count == 0:
                                print(f"\n⚠️  读取流异常: {e}")
                        
                        elapsed_time = (datetime.now() - start_time).total_seconds()
                        
                        if event_count > 0:
                            if retry_count > 0:
                                print(f"✅ 重试成功! 收到 {event_count} 个SSE事件 (耗时 {elapsed_time:.2f}s)")
                            response.success()
                            success = True
                        else:
                            if retry_count == 0:
                                print(f"⚠️  状态码200但未收到SSE事件")
                                print(f"📦 实际响应内容:\n{full_response[:800]}")
                            response.failure("未收到SSE事件")
                            success = True
                    elif response.status_code == 0:
                        if retry_count < max_retries:
                            retry_count += 1
                            continue
                        else:
                            response.failure("连接失败(状态码0)")
                            success = True
                    else:
                        if retry_count == 0:
                            print(f"\n❌ 请求失败! 状态码: {response.status_code}")
                        response.failure(f"状态码: {response.status_code}")
                        success = True
                    
            except Exception as e:
                if "ConnectionError" in str(e) or "Timeout" in str(e) or "status code: 0" in str(e).lower():
                    if retry_count < max_retries:
                        retry_count += 1
                        continue
                    else:
                        print(f"\n❌ 重试{max_retries}次后仍失败: {e}")
                        self.environment.events.request.fire(
                            request_type="POST",
                            name="开启联网检索对话",
                            response_time=0,
                            response_length=0,
                            exception=e,
                            context={}
                        )
                        success = True
                else:
                    if retry_count == 0:
                        print(f"\n❌ 异常: {e}")
                    self.environment.events.request.fire(
                        request_type="POST",
                        name="开启联网检索对话",
                        response_time=0,
                        response_length=0,
                        exception=e,
                        context={}
                    )
                    success = True
