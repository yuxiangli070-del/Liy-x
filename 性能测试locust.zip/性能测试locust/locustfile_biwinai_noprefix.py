from locust import HttpUser, task, between, events
import json
import uuid
import random
from datetime import datetime


class Config:
    """佰维AI通用入口测试配置 - 正确路径版本"""
    
    HOST = "http://192.168.0.130:8090"
    
    BASE_PATH = "/prod-api"
    
    AUTH_TOKEN = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
    
    MIN_WAIT = 2
    MAX_WAIT = 5
    
    TEST_USER_ID = 1
    
    TEST_MESSAGES = [
        "帮我总结一下最近的AI发展趋势",
        "请解释一下什么是大语言模型",
        "如何使用Python进行数据分析",
        "介绍一下机器学习的基本概念",
        "什么是深度学习",
        "帮我写一个简单的Python函数",
        "解释一下RESTful API的设计原则",
        "如何进行代码性能优化",
        "什么是微服务架构",
        "介绍一下常见的数据库类型"
    ]


def generate_uuid():
    """生成UUID"""
    return str(uuid.uuid4())


class BiwinAIUser(HttpUser):
    """佰维AI平台测试用户"""
    
    wait_time = between(Config.MIN_WAIT, Config.MAX_WAIT)
    
    def on_start(self):
        """用户启动时初始化"""
        self.session_id = None
        self.message_ids = []
        self.default_headers = {
            "Authorization": f"Bearer {Config.AUTH_TOKEN}",
            "Content-Type": "application/json"
        }
    
    @task(5)
    def test_chat_agui_run(self):
        """测试主对话接口（高优先级）- 权重5"""
        if not self.session_id:
            self.create_session()
        
        if not self.session_id:
            return
        
        thread_id = self.session_id
        run_id = f"run-{datetime.now().strftime('%Y%m%d%H%M%S')}-{random.randint(1000, 9999)}"
        message_id = f"msg-{generate_uuid()}"
        user_message = random.choice(Config.TEST_MESSAGES)
        
        payload = {
            "threadId": thread_id,
            "runId": run_id,
            "messages": [
                {
                    "id": message_id,
                    "role": "user",
                    "content": user_message
                }
            ],
            "forwardedProps": {
                "mode": "chat",
                "thinkingEnabled": True,
                "searchEnabled": False,
                "stream": True,
                "attachments": []
            }
        }
        
        headers = self.default_headers.copy()
        headers["Accept"] = "text/event-stream"
        
        with self.client.post(
            f"{Config.BASE_PATH}/agent/chat/agui/run",
            json=payload,
            headers=headers,
            catch_response=True,
            stream=True
        ) as response:
            if response.status_code == 200:
                try:
                    event_count = 0
                    for line in response.iter_lines():
                        if line:
                            decoded_line = line.decode('utf-8')
                            if decoded_line.startswith('data:'):
                                event_count += 1
                    if event_count > 0:
                        response.success()
                    else:
                        response.failure("未收到SSE事件")
                except Exception as e:
                    response.failure(f"读取SSE流失败: {str(e)}")
            else:
                response.failure(f"状态码: {response.status_code}")
    
    @task(3)
    def test_session_list(self):
        """测试查询会话列表（高优先级）- 权重3"""
        with self.client.get(
            f"{Config.BASE_PATH}/agent/ai/session/list",
            params={"pageNum": 1, "pageSize": 20},
            headers={"Authorization": f"Bearer {Config.AUTH_TOKEN}"},
            catch_response=True
        ) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("code") == 200:
                        response.success()
                        if data.get("rows"):
                            self.session_id = data["rows"][0]["sessionId"]
                    else:
                        response.failure(f"业务错误: {data.get('msg')}")
                except Exception as e:
                    response.failure(f"解析响应失败: {str(e)}")
            else:
                response.failure(f"状态码: {response.status_code}")
    
    @task(2)
    def test_create_session(self):
        """测试创建会话（高优先级）- 权重2"""
        session_id = generate_uuid()
        title = f"性能测试会话-{datetime.now().strftime('%H%M%S')}"
        
        payload = {
            "sessionId": session_id,
            "title": title,
            "userId": Config.TEST_USER_ID
        }
        
        with self.client.post(
            f"{Config.BASE_PATH}/agent/ai/session",
            json=payload,
            headers=self.default_headers,
            catch_response=True
        ) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("code") == 200:
                        self.session_id = session_id
                        response.success()
                    else:
                        response.failure(f"业务错误: {data.get('msg')}")
                except Exception as e:
                    response.failure(f"解析响应失败: {str(e)}")
            else:
                response.failure(f"状态码: {response.status_code}")
    
    @task(1)
    def test_message_list(self):
        """测试查询消息列表（高优先级）- 权重1"""
        if not self.session_id:
            self.test_session_list()
        
        if not self.session_id:
            return
        
        with self.client.get(
            f"{Config.BASE_PATH}/agent/ai/message/list",
            params={
                "sessionId": self.session_id,
                "pageNum": 1,
                "pageSize": 20,
                "order": "asc"
            },
            headers={"Authorization": f"Bearer {Config.AUTH_TOKEN}"},
            catch_response=True
        ) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("code") == 200:
                        response.success()
                    else:
                        response.failure(f"业务错误: {data.get('msg')}")
                except Exception as e:
                    response.failure(f"解析响应失败: {str(e)}")
            else:
                response.failure(f"状态码: {response.status_code}")
    
    @task(1)
    def test_get_session_detail(self):
        """测试查询单个会话（中优先级）- 权重1"""
        if not self.session_id:
            self.test_session_list()
        
        if not self.session_id:
            return
        
        with self.client.get(
            f"{Config.BASE_PATH}/agent/ai/session/{self.session_id}",
            headers={"Authorization": f"Bearer {Config.AUTH_TOKEN}"},
            catch_response=True
        ) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("code") == 200:
                        response.success()
                    else:
                        response.failure(f"业务错误: {data.get('msg')}")
                except Exception as e:
                    response.failure(f"解析响应失败: {str(e)}")
            else:
                response.failure(f"状态码: {response.status_code}")
    
    @task(1)
    def test_update_session_title(self):
        """测试修改会话标题（中优先级）- 权重1"""
        if not self.session_id:
            self.test_session_list()
        
        if not self.session_id:
            return
        
        new_title = f"修改标题-{datetime.now().strftime('%H%M%S')}"
        
        with self.client.put(
            f"{Config.BASE_PATH}/agent/ai/session/title",
            data={
                "sessionId": self.session_id,
                "title": new_title
            },
            headers={
                "Authorization": f"Bearer {Config.AUTH_TOKEN}",
                "Content-Type": "application/x-www-form-urlencoded"
            },
            catch_response=True
        ) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("code") == 200:
                        response.success()
                    else:
                        response.failure(f"业务错误: {data.get('msg')}")
                except Exception as e:
                    response.failure(f"解析响应失败: {str(e)}")
            else:
                response.failure(f"状态码: {response.status_code}")
    
    def create_session(self):
        """辅助方法：创建会话"""
        session_id = generate_uuid()
        title = f"自动创建-{datetime.now().strftime('%H%M%S')}"
        
        payload = {
            "sessionId": session_id,
            "title": title,
            "userId": Config.TEST_USER_ID
        }
        
        response = self.client.post(
            f"{Config.BASE_PATH}/agent/ai/session",
            json=payload,
            headers=self.default_headers
        )
        
        if response.status_code == 200:
            try:
                data = response.json()
                if data.get("code") == 200:
                    self.session_id = session_id
            except:
                pass


@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """测试开始事件"""
    print("=" * 80)
    print("佰维AI通用入口 - Locust并发测试启动（无/biwinAi前缀版本）")
    print("=" * 80)
    print(f"目标服务器: {Config.HOST}")
    print(f"基础路径: {Config.BASE_PATH if Config.BASE_PATH else '（无）'}")
    print(f"完整请求示例: {Config.HOST}/agent/ai/session/list")
    print(f"等待时间: {Config.MIN_WAIT}-{Config.MAX_WAIT}秒")
    print(f"测试用户ID: {Config.TEST_USER_ID}")
    print(f"测试消息数量: {len(Config.TEST_MESSAGES)}")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    print("\n测试接口及权重分布:")
    print("  [权重5] POST /agent/chat/agui/run - 主对话接口(SSE)")
    print("  [权重3] GET  /agent/ai/session/list - 查询会话列表")
    print("  [权重2] POST /agent/ai/session - 创建会话")
    print("  [权重1] GET  /agent/ai/message/list - 查询消息列表")
    print("  [权重1] GET  /agent/ai/session/{id} - 查询会话详情")
    print("  [权重1] PUT  /agent/ai/session/title - 修改会话标题")
    print("=" * 80)


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """测试结束事件"""
    print("=" * 80)
    print("测试完成")
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
