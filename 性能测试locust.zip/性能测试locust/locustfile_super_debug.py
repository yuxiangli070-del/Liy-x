from locust import HttpUser, task, between
import json
import uuid
from datetime import datetime


class SuperDebugUser(HttpUser):
    wait_time = between(5, 8)
    
    @task
    def debug_session_list(self):
        """调试会话列表接口 - 最详细的诊断信息"""
        
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
        
        url = "/prod-api/agent/ai/session/list"
        params = {"pageNum": 1, "pageSize": 20}
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        print("\n" + "="*100)
        print("🔍🔍🔍 超级调试模式 - 会话列表接口")
        print("="*100)
        print(f"📍 完整请求URL: {self.host}{url}")
        print(f"📍 请求方法: GET")
        print(f"📍 请求参数: {json.dumps(params, ensure_ascii=False)}")
        print(f"📍 请求头:")
        for k, v in headers.items():
            print(f"   {k}: {v}")
        print("="*100)
        
        try:
            response = self.client.get(
                url,
                params=params,
                headers=headers,
                catch_response=True,
                name="DEBUG-会话列表"
            )
            
            print("\n" + "="*100)
            print("📊📊📊 响应详情")
            print("="*100)
            print(f"✅ 状态码: {response.status_code}")
            print(f"✅ 响应头:")
            for k, v in response.headers.items():
                print(f"   {k}: {v}")
            print(f"✅ Content-Type: {response.headers.get('Content-Type', '未返回')}")
            print(f"✅ 响应长度: {len(response.text)} 字符")
            print(f"\n✅ 完整响应内容:")
            print("-"*100)
            print(response.text)
            print("-"*100)
            print("="*100)
            
            if response.status_code == 200:
                content_type = response.headers.get('Content-Type', '')
                if 'json' in content_type.lower():
                    try:
                        data = response.json()
                        print(f"\n🎉 JSON解析成功!")
                        print(f"   code: {data.get('code')}")
                        print(f"   msg: {data.get('msg')}")
                        if 'rows' in data:
                            print(f"   rows数量: {len(data.get('rows', []))}")
                        response.success()
                    except Exception as e:
                        print(f"\n❌ JSON解析失败: {e}")
                        response.failure(f"JSON解析失败: {e}")
                else:
                    print(f"\n❌ 响应不是JSON格式!")
                    print(f"   Content-Type: {content_type}")
                    response.failure(f"非JSON响应: {content_type}")
            elif response.status_code == 401:
                print(f"\n❌ 401 未授权 - Token已失效!")
                response.failure("Token失效")
            elif response.status_code == 403:
                print(f"\n❌ 403 禁止访问 - 权限不足!")
                response.failure("权限不足")
            elif response.status_code == 404:
                print(f"\n❌ 404 未找到 - 路径错误!")
                response.failure("路径错误")
            elif response.status_code == 405:
                print(f"\n❌ 405 方法不允许!")
                response.failure("方法不允许")
            else:
                print(f"\n❌ 请求失败: {response.status_code}")
                response.failure(f"状态码: {response.status_code}")
                
        except Exception as e:
            print(f"\n❌❌❌ 请求异常: {e}")
            import traceback
            traceback.print_exc()
    
    @task
    def debug_create_session(self):
        """调试创建会话接口"""
        
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
        
        url = "/prod-api/agent/ai/session"
        session_id = str(uuid.uuid4())
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')
        
        payload = {
            "sessionId": session_id,
            "title": f"调试会话-{timestamp}",
            "userId": 1
        }
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        print("\n" + "="*100)
        print("🔍🔍🔍 超级调试模式 - 创建会话接口")
        print("="*100)
        print(f"📍 完整请求URL: {self.host}{url}")
        print(f"📍 请求方法: POST")
        print(f"📍 请求体:")
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        print(f"📍 请求头:")
        for k, v in headers.items():
            print(f"   {k}: {v}")
        print("="*100)
        
        try:
            response = self.client.post(
                url,
                json=payload,
                headers=headers,
                catch_response=True,
                name="DEBUG-创建会话"
            )
            
            print("\n" + "="*100)
            print("📊📊📊 响应详情")
            print("="*100)
            print(f"✅ 状态码: {response.status_code}")
            print(f"✅ Content-Type: {response.headers.get('Content-Type', '未返回')}")
            print(f"✅ 响应长度: {len(response.text)} 字符")
            print(f"\n✅ 完整响应内容:")
            print("-"*100)
            print(response.text)
            print("-"*100)
            print("="*100)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    print(f"\n🎉 JSON解析成功!")
                    print(f"   code: {data.get('code')}")
                    print(f"   msg: {data.get('msg')}")
                    response.success()
                except Exception as e:
                    print(f"\n❌ JSON解析失败: {e}")
                    response.failure(f"JSON解析失败: {e}")
            elif response.status_code == 401:
                print(f"\n❌ 401 未授权 - Token已失效!")
                response.failure("Token失效")
            elif response.status_code == 405:
                print(f"\n❌ 405 方法不允许!")
                response.failure("方法不允许")
            else:
                print(f"\n❌ 请求失败: {response.status_code}")
                response.failure(f"状态码: {response.status_code}")
                
        except Exception as e:
            print(f"\n❌❌❌ 请求异常: {e}")
            import traceback
            traceback.print_exc()
