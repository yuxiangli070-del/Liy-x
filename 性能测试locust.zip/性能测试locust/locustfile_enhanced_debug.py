from locust import HttpUser, task, between
import json


class EnhancedDebugUser(HttpUser):
    wait_time = between(3, 5)
    
    @task
    def test_with_full_headers(self):
        """带完整请求头的测试"""
        
        token = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo2Mzk5NzgxMjksInVzZXJfa2V5IjoiMmU1MDc4MGEtODM3Ni00YWYzLTg5NmEtY2ZiMWRkZWU0YmQ3IiwidXNlcm5hbWUiOiJTWjAxNTkifQ.HmSdXlBcL1TRhh-qqF0pS28qACytPzDU1RHtgVikU6a6kclPm89C46I2Mq3v812nsG1g4bHPifE1oVSnkgGMaQ"
        
        url = "/prod-api/agent/ai/session/list"
        params = {"pageNum": 1, "pageSize": 20}
        
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Locust/PerformanceTest"
        }
        
        print(f"\n{'='*80}")
        print(f"请求URL: {self.host}{url}")
        print(f"请求参数: {params}")
        print(f"请求头: {json.dumps(headers, indent=2, ensure_ascii=False)}")
        print(f"{'='*80}")
        
        response = self.client.get(
            url,
            params=params,
            headers=headers,
            catch_response=True,
            name="/prod-api/agent/ai/session/list"
        )
        
        print(f"\n{'='*80}")
        print(f"响应状态码: {response.status_code}")
        print(f"响应Content-Type: {response.headers.get('Content-Type', 'Unknown')}")
        print(f"响应长度: {len(response.text)} 字符")
        print(f"\n响应内容（前1000字符）:")
        print(response.text[:1000])
        print(f"{'='*80}\n")
        
        if response.status_code == 200:
            content_type = response.headers.get('Content-Type', '')
            if 'application/json' in content_type:
                try:
                    data = response.json()
                    print(f"✅ JSON解析成功!")
                    print(f"   code: {data.get('code')}")
                    print(f"   msg: {data.get('msg')}")
                    if 'rows' in data:
                        print(f"   rows数量: {len(data.get('rows', []))}")
                    response.success()
                except Exception as e:
                    print(f"❌ JSON解析失败: {e}")
                    response.failure(f"JSON解析失败: {e}")
            else:
                print(f"❌ 响应不是JSON格式: {content_type}")
                response.failure(f"非JSON响应: {content_type}")
        elif response.status_code == 401:
            print(f"❌ 401 未授权 - Token失效")
            response.failure("Token失效")
        elif response.status_code == 403:
            print(f"❌ 403 禁止访问")
            response.failure("权限不足")
        elif response.status_code == 404:
            print(f"❌ 404 未找到")
            response.failure("路径错误")
        elif response.status_code == 405:
            print(f"❌ 405 方法不允许")
            response.failure("方法不允许")
        else:
            print(f"❌ 请求失败: {response.status_code}")
            response.failure(f"状态码: {response.status_code}")
