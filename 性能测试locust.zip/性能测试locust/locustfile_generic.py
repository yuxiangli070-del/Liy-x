from locust import HttpUser, task, between, events
import csv
import random
import json
import os
from datetime import datetime


class Config:
    """通用测试配置 - 通过环境变量或修改此处配置"""
    
    # 基础配置
    HOST = os.getenv("LOCUST_HOST", "http://localhost:8080")
    
    # 并发配置
    MIN_WAIT = int(os.getenv("LOCUST_MIN_WAIT", "1"))
    MAX_WAIT = int(os.getenv("LOCUST_MAX_WAIT", "3"))
    
    # 请求配置
    API_METHOD = os.getenv("LOCUST_API_METHOD", "POST").upper()
    API_PATH = os.getenv("LOCUST_API_PATH", "/prod-api/api/file/audit/retry")
    
    # 请求头配置
    HEADERS = json.loads(os.getenv("LOCUST_HEADERS", "{}"))
    
    # 请求体模板（支持占位符替换）
    BODY_TEMPLATE = os.getenv("LOCUST_BODY_TEMPLATE", '{"fileIds": ["{fileIds}"], "handler": "{handler}"}')
    
    # CSV数据文件
    CSV_FILE = os.getenv("LOCUST_CSV_FILE", "test_data.csv")
    
    # 是否使用CSV数据驱动
    USE_CSV = os.getenv("LOCUST_USE_CSV", "true").lower() == "true"
    
    # 固定请求体（不使用CSV时）
    FIXED_BODY = json.loads(os.getenv("LOCUST_FIXED_BODY", "{}"))


def load_csv_data(csv_file):
    """加载CSV测试数据"""
    data = []
    if not os.path.exists(csv_file):
        print(f"警告: CSV文件 {csv_file} 不存在，将使用固定请求体")
        return data
    
    with open(csv_file, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    
    print(f"成功加载 {len(data)} 条测试数据")
    return data


def render_template(template_str, data_dict):
    """替换模板中的占位符 {key}"""
    result = template_str
    for key, value in data_dict.items():
        result = result.replace(f"{{{key}}}", str(value))
    return result


class GenericAPITestUser(HttpUser):
    """通用API测试用户"""
    
    # 从配置读取等待时间
    wait_time = between(Config.MIN_WAIT, Config.MAX_WAIT)
    
    # 类变量：存储CSV数据
    csv_data = []
    
    def on_start(self):
        """用户启动时初始化"""
        if Config.USE_CSV and not GenericAPITestUser.csv_data:
            GenericAPITestUser.csv_data = load_csv_data(Config.CSV_FILE)
        
        if Config.USE_CSV and GenericAPITestUser.csv_data:
            self.test_data = random.choice(GenericAPITestUser.csv_data)
        else:
            self.test_data = {}
    
    @task
    def execute_request(self):
        """执行API请求"""
        # 准备请求头
        headers = Config.HEADERS.copy() if Config.HEADERS else {}
        
        # 准备请求体
        if Config.USE_CSV and self.test_data:
            body_str = render_template(Config.BODY_TEMPLATE, self.test_data)
            payload = json.loads(body_str)
        else:
            payload = Config.FIXED_BODY
        
        # 根据HTTP方法发送请求
        method = Config.API_METHOD
        url = Config.API_PATH
        
        if method == "GET":
            self.client.get(url, headers=headers, params=payload, catch_response=True)
        elif method == "POST":
            self.client.post(url, json=payload, headers=headers, catch_response=True)
        elif method == "PUT":
            self.client.put(url, json=payload, headers=headers, catch_response=True)
        elif method == "DELETE":
            self.client.delete(url, json=payload, headers=headers, catch_response=True)
        elif method == "PATCH":
            self.client.patch(url, json=payload, headers=headers, catch_response=True)
        else:
            print(f"不支持的HTTP方法: {method}")


@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """测试开始时打印配置信息"""
    print("=" * 80)
    print("Locust 通用并发测试启动")
    print("=" * 80)
    print(f"目标主机: {Config.HOST}")
    print(f"API路径: {Config.API_METHOD} {Config.API_PATH}")
    print(f"等待时间: {Config.MIN_WAIT}-{Config.MAX_WAIT}秒")
    print(f"使用CSV: {Config.USE_CSV}")
    if Config.USE_CSV:
        print(f"CSV文件: {Config.CSV_FILE}")
    if Config.HEADERS:
        print(f"自定义请求头: {json.dumps(Config.HEADERS, ensure_ascii=False)}")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """测试结束时打印统计信息"""
    print("=" * 80)
    print("测试完成")
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
