﻿# 通用入口接口文档

> 模块：`ruoyi-agent`（通用智能体服务）

---

## 1. AGUI 主对话

### 1.1 运行对话（AGUI + SSE 流式）

**使用场景**：用户在 AGUI 对话页面发送消息，需要按 AgentScope 标准事件流展示推理/工具/正文时调用。

**接口作用**：接收 `RunAgentInput`，经校验后映射为内部 `ChatRequest`，根据 `mode` 分流处理，将 `AguiEvent` 流通过 SSE 返回，并每 15 秒发送一次 keepAlive 心跳。

**接口 URL**：`/agent/chat/agui/run`

**接口 Method**：`POST`

**请求头**：
```
Authorization: Bearer {token}
Content-Type: application/json
Accept: text/event-stream
```

**接口依赖**：无。`threadId` 在映射中作为 `sessionId` 使用。

**接口入参**：

请求体为 JSON，类型为 `RunAgentInput`。

```json
{
  "threadId": "8f0e3c2a-6b1d-4a9e-9c0d-1234567890ab",
  "runId": "run-20260423-0001",
  "messages": [
    { "id": "msg-001", "role": "user", "content": "帮我总结附件里的要点" }
  ],
  "forwardedProps": {
    "mode": "chat",
    "thinkingEnabled": true,
    "searchEnabled": false,
    "stream": true,
    "attachments": []
  }
}
```

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `threadId` | 对话线程 ID，映射为内部 `sessionId` | 必填 | String | 非空，非空白 |
| `runId` | 本次执行运行 ID | 必填 | String | 非空，非空白 |
| `messages` | AGUI 消息列表 | 必填 | Array | 非空，至少一条 `role` 为 `"user"` |
| `messages[].id` | 消息唯一标识 | 必填 | String | UUID 格式，如 `msg-xxx` |
| `messages[].role` | 消息角色 | 必填 | String | 至少一条为 `user` |
| `messages[].content` | 用户消息内容 | 可选 | String | 可为空串 |
| `forwardedProps` | 业务扩展参数 | 建议有 | Object | 建议传 `{}` 而非 `null` |
| `forwardedProps.mode` | 模式 | 可选 | String | 缺省 `chat`，可选 `agent` |
| `forwardedProps.temperature` | 温度 | 可选 | Number | 可解析为 Double |
| `forwardedProps.maxTokens` | 最大 token | 可选 | Integer | 可解析为 Integer |
| `forwardedProps.thinkingEnabled` | 是否输出推理链 | 可选 | Boolean | 缺省 `false` |
| `forwardedProps.searchEnabled` | 是否启用联网/搜索 | 可选 | Boolean | 缺省 `false` |
| `forwardedProps.stream` | 是否流式 | 可选 | Boolean | 缺省 `true` |
| `forwardedProps.attachments` | 附件列表 | 可选 | Array | 见下表 |

**`forwardedProps.attachments` 子结构**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `attachmentId` | String | 附件唯一标识 |
| `fileName` | String | 文件名 |
| `filePath` | String | 文件路径 |
| `fileSize` | Long | 文件大小 |
| `fileType` | String | 文件类型 |
| `mimeType` | String | MIME 类型 |
| `content` | String | 内容 |
| `url` | String | URL |
| `kbId` | String | 知识库 ID |
| `kbDocumentId` | String | 知识库文档 ID |

**接口出参**：

响应格式为 SSE（Server-Sent Events），Content-Type 为 `text/event-stream`。

SSE 消息示例：
```
event: message
id: 1
data: {"type":"RunStarted","threadId":"xxx","runId":"xxx"}

event: message
id: 2
data: {"type":"TextMessageContent","content":"片段内容"}

: keep-alive

event: message
id: N
data: {"type":"RunFinished","threadId":"xxx","runId":"xxx"}
```

**SSE 消息结构说明**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `event` | String | 事件类型，固定为 `message` |
| `id` | String | 消息序号 |
| `data` | String | JSON 格式的 `AguiEvent` |

**data 字段内容结构**（按 `type` 区分）：

| type | 字段 | 类型 | 说明 |
|------|------|------|------|
| `RunStarted` | `threadId`, `runId` | String | 运行开始 |
| `ReasoningStart` | - | - | 推理开始 |
| `ReasoningMessageChunk` | `content` | String | 推理内容片段 |
| `ReasoningEnd` | - | - | 推理结束 |
| `TextMessageStart` | - | - | 正文开始 |
| `TextMessageContent` | `content` | String | 正文内容片段 |
| `TextMessageEnd` | - | - | 正文结束 |
| `RunFinished` | `threadId`, `runId` | String | 运行结束 |
| `Raw` | `kind`, `...` | - | 原始事件，含 `tool_activity`/`sources`/`error` 等 |

**异常响应**：
- 入参校验失败：HTTP 400，响应体示例 `{"error":"threadId 不能为空"}`
- 流中错误：通过 SSE 发送 `kind=error` 的 Raw 事件

**说明**：
- `userId` 不在 JSON 中传递，从 `SecurityUtils.getUserId()` 注入，若 `null` 或 `0L`，代码中默认为 `1L`
- `forwardedProps` 建议传 `{}` 而非 `null`，避免 NPE
- `messages` 数组中的每个消息对象**必须包含 `id` 字段**，否则后端反序列化报错
- 本接口为 POST，需使用 `fetch` + `ReadableStream` 读取，不能直接用 `EventSource`

---

## 2. 会话管理

### 2.1 查询会话列表

**使用场景**：用户打开对话列表页面时调用。

**接口作用**：查询当前用户的会话列表，支持分页。

**接口 URL**：`/agent/ai/session/list`

**接口 Method**：`GET`

**请求头**：
```
Authorization: Bearer {token}
```

**接口依赖**：无

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `pageNum` | 页码 | 可选 | Integer | 缺省 `1` |
| `pageSize` | 每页数量 | 可选 | Integer | 缺省 `20` |

**接口出参**：

正常响应（分页）：
```json
{
  "code": 200,
  "msg": "操作成功",
  "rows": [
    {
      "id": 1,
      "sessionId": "8f0e3c2a-6b1d-4a9e-9c0d-1234567890ab",
      "title": "会话标题",
      "userId": 1,
      "pinned": 0,
      "createTime": "2026-04-23 10:00:00",
      "updateTime": "2026-04-23 10:30:00"
    }
  ],
  "total": 100
}
```

---

### 2.2 查询单个会话

**使用场景**：用户查看会话详情时调用。

**接口作用**：根据 `sessionId` 查询会话详情。

**接口 URL**：`/agent/ai/session/{sessionId}`

**接口 Method**：`GET`

**请求头**：
```
Authorization: Bearer {token}
```

**接口依赖**：无

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID，路径参数 | 必填 | String | 与 AGUI `threadId` 同形 |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "id": 1,
    "sessionId": "8f0e3c2a-6b1d-4a9e-9c0d-1234567890ab",
    "title": "会话标题",
    "userId": 1,
    "pinned": 0,
    "createTime": "2026-04-23 10:00:00",
    "updateTime": "2026-04-23 10:30:00"
  }
}
```

---

### 2.3 创建会话

**使用场景**：用户点击「新建对话」时调用。

**接口作用**：创建新会话，若未传 `sessionId` 则自动生成 UUID。

**接口 URL**：`/agent/ai/session`

**接口 Method**：`POST`

**请求头**：
```
Authorization: Bearer {token}
Content-Type: application/json
```

**接口依赖**：无

**接口入参**：

```json
{
  "sessionId": "8f0e3c2a-6b1d-4a9e-9c0d-1234567890ab",
  "title": "新会话",
  "userId": 1
}
```

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID | 可选 | String | 不传则自动生成 UUID |
| `title` | 会话标题 | 可选 | String | 最大 255 字符 |
| `userId` | 用户 ID | 可选 | Long | 不传则取当前登录用户 |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {
    "sessionId": "8f0e3c2a-6b1d-4a9e-9c0d-1234567890ab",
    "title": "新会话"
  }
}
```

---

### 2.4 修改会话标题

**使用场景**：用户修改会话标题时调用。

**接口作用**：根据 `sessionId` 更新会话标题。

**接口 URL**：`/agent/ai/session/title`

**接口 Method**：`PUT`

**请求头**：
```
Authorization: Bearer {token}
Content-Type: application/x-www-form-urlencoded
```

**接口依赖**：需先调用 2.1 或 2.3 获取 `sessionId`

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID | 必填 | String | - |
| `title` | 新标题 | 必填 | String | 最大 255 字符 |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功"
}
```

---

### 2.5 置顶会话

**使用场景**：用户置顶某个会话时调用。

**接口作用**：将指定会话标记为置顶状态。

**接口 URL**：`/agent/ai/session/pin`

**接口 Method**：`PUT`

**请求头**：
```
Authorization: Bearer {token}
Content-Type: application/x-www-form-urlencoded
```

**接口依赖**：需先调用 2.1 获取 `sessionId`

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID | 必填 | String | - |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功"
}
```

---

### 2.6 取消置顶会话

**使用场景**：用户取消置顶某个会话时调用。

**接口作用**：将指定会话取消置顶状态。

**接口 URL**：`/agent/ai/session/unpin`

**接口 Method**：`PUT`

**请求头**：
```
Authorization: Bearer {token}
Content-Type: application/x-www-form-urlencoded
```

**接口依赖**：需先调用 2.1 获取 `sessionId`

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID | 必填 | String | - |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功"
}
```

---

### 2.7 删除会话

**使用场景**：用户删除整个会话时调用。

**接口作用**：根据 `sessionId` 删除会话（软删除）。

**接口 URL**：`/agent/ai/session/{sessionId}`

**接口 Method**：`DELETE`

**请求头**：
```
Authorization: Bearer {token}
```

**接口依赖**：需先调用 2.1 获取 `sessionId`

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID，路径参数 | 必填 | String | 与 AGUI `threadId` 同形 |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功"
}
```

失败响应（未删除任何行）：
```json
{
  "code": 500,
  "msg": "操作失败"
}
```

---

## 3. 消息管理

### 3.1 查询消息列表

**使用场景**：用户查看某个会话的历史消息时调用。

**接口作用**：根据 `sessionId` 查询消息列表，支持分页和排序。

**接口 URL**：`/agent/ai/message/list`

**接口 Method**：`GET`

**请求头**：
```
Authorization: Bearer {token}
```

**接口依赖**：需先调用 2.1 或 1.1 获取 `sessionId`

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `sessionId` | 会话 ID | 必填 | String | - |
| `pageNum` | 页码 | 可选 | Integer | 缺省 `1` |
| `pageSize` | 每页数量 | 可选 | Integer | 缺省 `20` |
| `order` | 排序方式 | 可选 | String | `asc`/`desc`，缺省 `asc` |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": [
    {
      "id": 1,
      "messageId": "msg-001",
      "sessionId": "8f0e3c2a-6b1d-4a9e-9c0d-1234567890ab",
      "role": "user",
      "content": "用户消息内容",
      "createTime": "2026-04-23 10:00:00"
    }
  ]
}
```

---

### 3.2 删除单条消息

**使用场景**：用户删除历史记录中的某条消息时调用。

**接口作用**：根据 `messageId` 删除单条消息（软删除）。

**接口 URL**：`/agent/ai/message/{messageId}`

**接口 Method**：`DELETE`

**请求头**：
```
Authorization: Bearer {token}
```

**接口依赖**：需先调用 3.1 获取 `messageId`

**接口入参**：

| 参数名 | 描述 | 是否必填 | 类型 | 边界值 / 特定值 |
|--------|------|----------|------|-----------------|
| `messageId` | 消息 ID，路径参数 | 必填 | String | 与列表接口返回的 ID 一致 |

**接口出参**：

正常响应：
```json
{
  "code": 200,
  "msg": "操作成功"
}
```

失败响应：
```json
{
  "code": 500,
  "msg": "操作失败"
}
```

---

## 4. 通用说明

### 4.1 认证方式

所有接口默认需在请求头携带：
```
Authorization: Bearer {token}
```

### 4.2 标准响应格式

**普通接口**：
```json
{
  "code": 200,
  "msg": "操作成功",
  "data": {}
}
```

**分页接口**：
```json
{
  "code": 200,
  "msg": "操作成功",
  "rows": [],
  "total": 0
}
```

**SSE 流式接口**：响应格式为 `text/event-stream`，见 1.1 说明。

### 4.3 网关路由

| 说明 | 值 |
|------|-----|
| 路由 | `Path=/agent/**` → `ruoyi-agent`，`StripPrefix=1` |

---

## 5. 接口自动化测试优先级说明

### 高优先级（核心业务流程，必须测试）

| 接口编号 | 接口名称 | 说明 |
|---|---|---|
| 1.1 | POST /agent/chat/agui/run | 主对话接口，前端 AGUI 页面调用 |
| 2.1 | GET /agent/ai/session/list | 查询会话列表，前端列表页调用 |
| 2.3 | POST /agent/ai/session | 创建会话，前端新建对话调用 |
| 2.7 | DELETE /agent/ai/session/{sessionId} | 删除会话，前端列表页调用 |
| 3.1 | GET /agent/ai/message/list | 查询消息列表，前端历史记录调用 |

### 中优先级（根据测试策略决定）

| 接口编号 | 接口名称 | 说明 |
|---|---|---|
| 2.2 | GET /agent/ai/session/{sessionId} | 查询单个会话详情 |
| 2.4 | PUT /agent/ai/session/title | 修改会话标题 |
| 2.5 | PUT /agent/ai/session/pin | 置顶会话 |
| 2.6 | PUT /agent/ai/session/unpin | 取消置顶会话 |
| 3.2 | DELETE /agent/ai/message/{messageId} | 删除单条消息 |

### 测试策略建议

1. **第一阶段**：优先测试高优先级接口，覆盖核心业务流程（对话、会话列表、创建会话、删除会话、消息列表）
2. **第二阶段**：根据产品要求，补充中优先级接口测试（标题修改、置顶/取消置顶、单条消息删除）

---

## 6. 相关文档

- `ruoyi-agent` 模块其他功能（知识库、ChatBI、MCP 等）见对应接口文档
