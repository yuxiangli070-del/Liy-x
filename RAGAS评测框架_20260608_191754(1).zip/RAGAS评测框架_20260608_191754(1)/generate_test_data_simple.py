"""
生成随机测试数据 - 简化版
用于 RAG 评测框架的测试数据生成工具
"""
import json
import random
from typing import List, Dict

# 测试场景
SCENARIOS = ["商品库存", "国际物流", "关税税费", "售后问题", "产品咨询", "促销活动"]

# 商品名称
PRODUCTS = [
    "蓝牙耳机", "智能手表", "笔记本电脑", "无线鼠标", "机械键盘",
    "平板电脑", "手机壳", "充电宝", "数据线", "充电器",
    "摄像头", "显示器", "音箱", "耳机", "路由器",
    "打印机", "扫描仪", "移动硬盘", "U盘", "存储卡"
]

# 问题模板
QUESTIONS = {
    "商品库存": [
        "查询{product}的库存",
        "{product}还有货吗",
        "现在{product}有多少库存",
        "{product}库存充足吗",
        "能否查看{product}的库存状态"
    ],
    "国际物流": [
        "查询{product}的物流信息",
        "{product}什么时候能到",
        "{product}的运输状态",
        "{product}的预计送达时间",
        "我的{product}到哪了"
    ],
    "关税税费": [
        "{product}需要交多少关税",
        "进口{product}的税费是多少",
        "{product}的关税计算",
        "购买{product}需要交哪些税",
        "{product}的清关费用"
    ],
    "售后问题": [
        "{product}如何退货",
        "{product}可以退换吗",
        "{product}的售后政策",
        "{product}坏了怎么办",
        "如何申请{product}的售后"
    ],
    "产品咨询": [
        "{product}的规格参数",
        "{product}有哪些功能",
        "{product}的使用方法",
        "{product}适合什么场景",
        "{product}怎么样"
    ],
    "促销活动": [
        "{product}有优惠活动吗",
        "{product}现在打几折",
        "购买{product}有什么赠品",
        "{product}的优惠券怎么用",
        "什么时候买{product}最便宜"
    ]
}

# 上下文模板
CONTEXTS = {
    "商品库存": [
        "{product}当前库存为{stock}件，位于{city}仓库。",
        "{product}现有库存{stock}件，预计{days}天后补货。",
        "{product}库存充足，当前有{stock}件可供销售。",
        "{product}库存不足，仅剩{stock}件，请尽快补货。"
    ],
    "国际物流": [
        "{product}已到达{city}，预计{days}天后送达。",
        "{product}正在{city}清关中，预计需要{days}个工作日。",
        "{product}物流状态：运输中，当前位置{city}。",
        "{product}预计{date}送达，请保持电话畅通。"
    ],
    "关税税费": [
        "{product}进口关税税率为{tax}%，预估税费{amount}元。",
        "{product}属于电子产品类别，适用{tax}%的进口税率。",
        "购买{product}需缴纳关税{amount}元，总计{total}元。",
        "{product}关税已包含在商品价格中，无需额外支付。"
    ],
    "售后问题": [
        "{product}支持{days}天无理由退换货，需保持商品完好。",
        "{product}质保期{months}个月，期间可享受免费维修服务。",
        "如需退换{product}，请联系客服提供订单号。",
        "{product}售后流程：申请→审核→寄回→退款。"
    ],
    "产品咨询": [
        "{product}采用高品质材料，性能稳定可靠。",
        "{product}主要功能包括：{features}。",
        "{product}适合{scenario}场景使用，支持多平台。",
        "{product}使用方法简单，请参考说明书操作。"
    ],
    "促销活动": [
        "{product}正在进行{discount}折优惠，活动截止{date}。",
        "购买{product}满{amount}元减{discount}元，限时优惠。",
        "{product}买一送一，赠品为数据线或保护套。",
        "新用户购买{product}可享受{discount}元优惠券。"
    ]
}

# 回答模板
ANSWERS = {
    "商品库存": [
        "您好！{product}当前库存为{stock}件，可以正常购买。",
        "{product}现有{stock}件库存，状态良好。",
        "查询到{product}库存{stock}件，建议尽快下单。",
        "{product}库存状态：{stock}件，1-3天送达。"
    ],
    "国际物流": [
        "您好！{product}当前状态：运输中，预计{date}送达。",
        "{product}物流信息：已到达{city}，正在派送中。",
        "{product}已到达{city}，预计{days}天后送达。",
        "您的{product}预计{days}天后送达，请耐心等待。"
    ],
    "关税税费": [
        "{product}的进口关税为{amount}元，已包含在价格中。",
        "购买{product}需缴纳综合税{amount}元。",
        "{product}关税计算：商品价值 × {tax}% = {amount}元。",
        "{product}符合个人自用条件，可享受优惠税率。"
    ],
    "售后问题": [
        "{product}支持{days}天无理由退换售后服务。",
        "如需售后，请联系客服申请退换货。",
        "{product}售后政策：{days}天退换，{months}个月质保。",
        "质量问题可以通过申请售后或换货解决。"
    ],
    "产品咨询": [
        "{product}的主要特点：高品质、多功能、便携耐用。",
        "{product}规格参数：性能稳定，功能全面。",
        "{product}适合办公和日常使用，性价比很高。",
        "{product}是一款非常不错的产品，值得购买。"
    ],
    "促销活动": [
        "{product}当前有{discount}折优惠活动，限时进行中。",
        "购买{product}可享受满减优惠，多买多省。",
        "{product}促销信息：{discount}折优惠，赠品多多。",
        "现在购买{product}最划算，优惠力度最大。"
    ]
}

CITIES = ["北京", "上海", "广州", "深圳", "杭州", "成都", "武汉", "南京"]
FEATURES = ["防水", "无线", "快充", "降噪", "便携", "高清", "智能"]
SCENARIOS_LIST = ["办公", "居家", "户外", "旅行", "学习"]

def generate_random_data(count: int = 10) -> List[Dict]:
    """
    生成随机测试数据
    
    Args:
        count: 生成的数据条数
    
    Returns:
        List[Dict]: 包含 question, contexts, answer 的测试数据列表
    """
    data = []
    
    for _ in range(count):
        # 随机选择场景
        scenario = random.choice(SCENARIOS)
        
        # 随机选择商品
        product = random.choice(PRODUCTS)
        
        # 生成问题
        question = random.choice(QUESTIONS[scenario]).format(product=product)
        
        # 生成上下文（1-3条）
        context_count = random.randint(1, 3)
        contexts = []
        for _ in range(context_count):
            ctx = random.choice(CONTEXTS[scenario]).format(
                product=product,
                stock=random.randint(1, 999),
                city=random.choice(CITIES),
                days=random.randint(1, 30),
                date=f"2026-06-{random.randint(10, 30)}",
                tax=random.randint(5, 30),
                amount=round(random.uniform(10, 500), 2),
                total=round(random.uniform(50, 1000), 2),
                months=random.randint(6, 24),
                features=', '.join(random.sample(FEATURES, 3)),
                scenario=random.choice(SCENARIOS_LIST),
                discount=random.randint(5, 9)
            )
            contexts.append(ctx)
        
        # 生成回答
        answer = random.choice(ANSWERS[scenario]).format(
            product=product,
            stock=random.randint(1, 999),
            city=random.choice(CITIES),
            days=random.randint(1, 15),
            date=f"2026-06-{random.randint(10, 30)}",
            tax=random.randint(5, 30),
            amount=round(random.uniform(10, 500), 2),
            months=random.randint(6, 24),
            discount=random.randint(5, 9)
        )
        
        data.append({
            "question": question,
            "contexts": contexts,
            "answer": answer,
            "scenario": scenario
        })
    
    return data

def save_to_json(data: List[Dict], filename: str = "test_data.json") -> None:
    """保存数据到 JSON 文件"""
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"已保存 {len(data)} 条测试数据到 {filename}")

def main():
    # 生成50条测试数据
    print("正在生成50条测试数据...")
    data = generate_random_data(50)
    
    # 保存到JSON文件
    save_to_json(data, "ragas_test_data.json")
    
    # 显示示例
    print("\n生成的数据示例：")
    for i, item in enumerate(data[:3], 1):
        print(f"\n[{i}] 场景: {item['scenario']}")
        print(f"   问题: {item['question']}")
        print(f"   上下文: {len(item['contexts'])} 条")
        print(f"   回答: {item['answer'][:50]}...")

if __name__ == "__main__":
    main()
