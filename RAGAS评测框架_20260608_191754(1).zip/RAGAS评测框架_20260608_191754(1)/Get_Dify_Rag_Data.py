"""
3、获取 Dify RAG 评测数据
调用 Dify RAG 应用，构造标准评测数据集
支持批量获取问答对和检索上下文
"""
import os
import json
import requests
from dotenv import load_dotenv
from typing import List, Dict, Any

# 加载环境配置
load_dotenv()

# Dify 配置
DIFY_URL = os.getenv("DIFY_URL", "http://192.168.1.249/v3/chat-messages")
DIFY_APP_KEY = os.getenv("DIFY_APP_KEY", "")

def call_dify_rag(question: str, timeout: int = 60) -> Dict[str, Any]:
    """
    调用本地 Dify RAG 应用，获取问答结果
    
    Args:
        question: 用户问题
        timeout: 请求超时时间
    
    Returns:
        dict: 包含 question, contexts, answer 的字典
    """
    if not DIFY_APP_KEY or DIFY_APP_KEY == "your-dify-app-key-here":
        raise ValueError("请在 .env 文件中配置 DIFY_APP_KEY")
    
    headers = {
        "Authorization": f"Bearer {DIFY_APP_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "inputs": {},
        "query": question,
        "response_mode": "blocking",
        "user": "ragas-test-user"
    }
    
    try:
        resp = requests.post(DIFY_URL, headers=headers, json=payload, timeout=timeout)
        resp.raise_for_status()
        res_data = resp.json()
        
        # 解析 Dify 返回：检索上下文 + 回答
        answer = res_data.get("answer", "")
        contexts = []
        retriever_res = res_data.get("metadata", {}).get("retriever_resources", [])
        for item in retriever_res:
            content = item.get("content", "")
            if content:
                contexts.append(content)
        
        return {
            "question": question,
            "contexts": contexts,
            "answer": answer
        }
    
    except requests.exceptions.RequestException as e:
        print(f"❌ 调用Dify失败 [{question}]: {str(e)}")
        return {
            "question": question,
            "contexts": [],
            "answer": ""
        }

def generate_rag_dataset(test_questions: List[str]) -> List[Dict[str, Any]]:
    """
    批量生成 RAG 评测数据集
    
    Args:
        test_questions: 测试问题列表
    
    Returns:
        list: 标准 RAG 评测数据集
    """
    rag_dataset = []
    total = len(test_questions)
    
    print(f"🚀 开始获取 RAG 数据，共 {total} 个问题")
    
    for i, question in enumerate(test_questions, 1):
        print(f"\n[{i}/{total}] 处理问题: {question}")
        data = call_dify_rag(question)
        rag_dataset.append(data)
        
        if data["contexts"]:
            print(f"   ✅ 检索到 {len(data['contexts'])} 个上下文片段")
        else:
            print(f"   ⚠️ 未检索到上下文")
        
        if data["answer"]:
            print(f"   ✅ 获取到回答（{len(data['answer'])} 字符）")
        else:
            print(f"   ❌ 未获取到回答")
    
    print(f"\n✅ 数据获取完成，共 {len(rag_dataset)} 条记录")
    return rag_dataset

# ------------------- 测试用问题列表（可自行扩充）-------------------
DEFAULT_TEST_QUESTIONS = [
    "请介绍项目背景",
    "该系统的部署步骤是什么",
    "DeepSeek模型有哪些特点",
    "系统支持哪些功能模块",
    "如何配置系统参数",
    "项目的技术架构是什么",
    "支持的数据源类型有哪些",
    "如何进行模型训练",
    "系统的性能指标如何",
    "如何进行故障排查"
]

if __name__ == "__main__":
    rag_dataset = generate_rag_dataset(DEFAULT_TEST_QUESTIONS)
    
    # 打印数据集
    print("\n" + "="*60)
    print("生成的 RAG 数据集：")
    print("="*60)
    
    for item in rag_dataset:
        print(f"\n问题：{item['question']}")
        print(f"检索片段数量：{len(item['contexts'])}")
        for j, ctx in enumerate(item['contexts'], 1):
            print(f"  片段{j}：{ctx[:100]}..." if len(ctx) > 100 else f"  片段{j}：{ctx}")
        print(f"回答：{item['answer'][:150]}..." if len(item['answer']) > 150 else f"回答：{item['answer']}")
    
    # 保存到 JSON 文件
    with open("rag_dataset.json", "w", encoding="utf-8") as f:
        json.dump(rag_dataset, f, ensure_ascii=False, indent=2)
    print(f"\n📄 数据集已保存至：rag_dataset.json")
