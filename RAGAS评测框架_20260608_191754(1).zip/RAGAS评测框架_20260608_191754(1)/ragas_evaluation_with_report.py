"""
Ragas 评测报告生成器
将测试数据带入 Ragas 评测，生成评测报告与饼状图
"""
import json
import os
import matplotlib.pyplot as plt
import pandas as pd
from datetime import datetime

# 设置中文支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 创建输出目录
output_dir = "./evaluation_results"
os.makedirs(output_dir, exist_ok=True)

def load_test_data(file_path: str = "ragas_test_data.json"):
    """加载测试数据"""
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    print(f"已加载 {len(data)} 条测试数据")
    return data

def simulate_ragas_evaluation(data):
    """
    模拟 Ragas 评测（实际使用时替换为真实评测）
    这里生成模拟的评测分数
    """
    import random
    
    results = []
    for item in data:
        # 模拟评测分数（实际使用中会调用 Ragas evaluate 函数）
        result = {
            "question": item["question"],
            "scenario": item.get("scenario", "未知"),
            "retrieval_precision": round(random.uniform(0.6, 1.0), 3),
            "retrieval_recall": round(random.uniform(0.6, 1.0), 3),
            "faithfulness": round(random.uniform(0.5, 1.0), 3),
            "answer_relevancy": round(random.uniform(0.5, 1.0), 3),
            "context_precision": round(random.uniform(0.6, 1.0), 3),
            "context_recall": round(random.uniform(0.6, 1.0), 3),
        }
        
        # 计算综合得分
        result["overall_score"] = round(
            (result["retrieval_precision"] + result["retrieval_recall"] + 
             result["faithfulness"] + result["answer_relevancy"]) / 4, 3
        )
        
        # 判断等级
        if result["overall_score"] >= 0.85:
            result["grade"] = "优秀"
        elif result["overall_score"] >= 0.75:
            result["grade"] = "良好"
        elif result["overall_score"] >= 0.65:
            result["grade"] = "合格"
        else:
            result["grade"] = "需改进"
        
        results.append(result)
    
    return results

def analyze_results(results):
    """分析评测结果"""
    analysis = {
        "total_cases": len(results),
        "avg_scores": {},
        "grade_distribution": {},
        "scenario_distribution": {},
        "scenario_scores": {},
        "score_ranges": {}
    }
    
    # 计算平均分数
    metrics = ["retrieval_precision", "retrieval_recall", "faithfulness", 
               "answer_relevancy", "overall_score"]
    
    for metric in metrics:
        scores = [r[metric] for r in results]
        analysis["avg_scores"][metric] = round(sum(scores) / len(scores), 3)
        analysis["score_ranges"][metric] = {
            "min": round(min(scores), 3),
            "max": round(max(scores), 3),
            "std": round(sum((s - analysis["avg_scores"][metric]) ** 2 for s in scores) / len(scores) ** 0.5, 3)
        }
    
    # 等级分布
    for r in results:
        grade = r["grade"]
        analysis["grade_distribution"][grade] = analysis["grade_distribution"].get(grade, 0) + 1
    
    # 场景分布
    for r in results:
        scenario = r.get("scenario", "未知")
        analysis["scenario_distribution"][scenario] = analysis["scenario_distribution"].get(scenario, 0) + 1
        
        # 场景得分
        if scenario not in analysis["scenario_scores"]:
            analysis["scenario_scores"][scenario] = []
        analysis["scenario_scores"][scenario].append(r["overall_score"])
    
    # 计算各场景平均分
    for scenario in analysis["scenario_scores"]:
        scores = analysis["scenario_scores"][scenario]
        analysis["scenario_scores"][scenario] = round(sum(scores) / len(scores), 3)
    
    return analysis

def generate_pie_charts(analysis, output_dir):
    """生成饼状图"""
    
    # 1. 等级分布饼状图
    plt.figure(figsize=(10, 8))
    grades = analysis["grade_distribution"]
    labels = list(grades.keys())
    sizes = list(grades.values())
    colors = ['#4CAF50', '#FFC107', '#FF9800', '#F44336'][:len(labels)]
    
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%',
            shadow=True, startangle=90, textprops={'fontsize': 12})
    plt.title('评测结果等级分布', fontsize=16, pad=20)
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "grade_distribution_pie.png"), dpi=150)
    plt.close()
    print("已生成: grade_distribution_pie.png")
    
    # 2. 场景分布饼状图
    plt.figure(figsize=(12, 8))
    scenarios = analysis["scenario_distribution"]
    labels = list(scenarios.keys())
    sizes = list(scenarios.values())
    colors = plt.cm.Set3(range(len(labels)))
    
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%',
            shadow=True, startangle=90, textprops={'fontsize': 10})
    plt.title('测试场景分布', fontsize=16, pad=20)
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "scenario_distribution_pie.png"), dpi=150)
    plt.close()
    print("已生成: scenario_distribution_pie.png")
    
    # 3. 各指标得分饼状图
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    metrics = ["retrieval_precision", "retrieval_recall", "faithfulness", "answer_relevancy"]
    titles = ["检索精度", "检索召回", "事实一致性", "回答相关性"]
    
    for idx, (metric, title) in enumerate(zip(metrics, titles)):
        ax = axes[idx // 2, idx % 2]
        scores = [0.7, 0.8, 0.9, 1.0]
        ranges = ["<0.7", "0.7-0.8", "0.8-0.9", "0.9-1.0"]
        counts = [0, 0, 0, 0]
        
        for r in results:
            score = r[metric]
            if score < 0.7:
                counts[0] += 1
            elif score < 0.8:
                counts[1] += 1
            elif score < 0.9:
                counts[2] += 1
            else:
                counts[3] += 1
        
        ax.pie(counts, labels=ranges, autopct='%1.1f%%', colors=['#FF6B6B', '#FFA94D', '#FFE066', '#69DB7C'])
        ax.set_title(f'{title}分布', fontsize=12)
    
    plt.suptitle('各评测指标得分分布', fontsize=16)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "metrics_distribution_pie.png"), dpi=150)
    plt.close()
    print("已生成: metrics_distribution_pie.png")
    
    # 4. 各场景得分对比
    plt.figure(figsize=(12, 6))
    scenarios = list(analysis["scenario_scores"].keys())
    scores = list(analysis["scenario_scores"].values())
    colors = plt.cm.Set2(range(len(scenarios)))
    
    plt.pie(scores, labels=[f"{s}\n({score:.2f})" for s, score in zip(scenarios, scores)], 
            colors=colors, autopct='%1.1f%%', startangle=90,
            textprops={'fontsize': 9})
    plt.title('各测试场景平均得分分布', fontsize=16, pad=20)
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "scenario_scores_pie.png"), dpi=150)
    plt.close()
    print("已生成: scenario_scores_pie.png")

def generate_bar_charts(analysis, output_dir):
    """生成柱状图"""
    
    # 1. 平均得分对比柱状图
    plt.figure(figsize=(10, 6))
    metrics = ["retrieval_precision", "retrieval_recall", "faithfulness", "answer_relevancy"]
    titles = ["检索精度", "检索召回", "事实一致性", "回答相关性"]
    scores = [analysis["avg_scores"][m] for m in metrics]
    colors = ['#3498db', '#2ecc71', '#e74c3c', '#9b59b6']
    
    bars = plt.bar(titles, scores, color=colors, edgecolor='black', linewidth=1.2)
    plt.ylim(0, 1.1)
    plt.ylabel('得分', fontsize=12)
    plt.xlabel('评测指标', fontsize=12)
    plt.title('各评测指标平均得分', fontsize=14)
    
    for bar, score in zip(bars, scores):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, 
                f'{score:.3f}', ha='center', va='bottom', fontsize=11)
    
    plt.axhline(y=0.75, color='gray', linestyle='--', linewidth=1, label='良好线(0.75)')
    plt.axhline(y=0.85, color='green', linestyle='--', linewidth=1, label='优秀线(0.85)')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "metrics_comparison_bar.png"), dpi=150)
    plt.close()
    print("已生成: metrics_comparison_bar.png")
    
    # 2. 等级分布柱状图
    plt.figure(figsize=(10, 6))
    grades = analysis["grade_distribution"]
    labels = list(grades.keys())
    counts = list(grades.values())
    colors = {'优秀': '#4CAF50', '良好': '#8BC34A', '合格': '#FFC107', '需改进': '#F44336'}
    bar_colors = [colors.get(g, '#9E9E9E') for g in labels]
    
    bars = plt.bar(labels, counts, color=bar_colors, edgecolor='black', linewidth=1.2)
    plt.ylabel('用例数量', fontsize=12)
    plt.xlabel('评测等级', fontsize=12)
    plt.title('评测结果等级分布', fontsize=14)
    
    for bar, count in zip(bars, counts):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, 
                f'{count}条\n({count/sum(counts)*100:.1f}%)', ha='center', va='bottom', fontsize=10)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "grade_distribution_bar.png"), dpi=150)
    plt.close()
    print("已生成: grade_distribution_bar.png")

def generate_report(analysis, results, output_dir):
    """生成文本报告"""
    
    report = []
    report.append("=" * 70)
    report.append("RAG 评测报告")
    report.append("=" * 70)
    report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("")
    
    # 概览
    report.append("【一、评测概览】")
    report.append("-" * 50)
    report.append(f"评测用例总数: {analysis['total_cases']}")
    report.append(f"测试场景数: {len(analysis['scenario_distribution'])}")
    report.append("")
    
    # 等级分布
    report.append("【二、等级分布统计】")
    report.append("-" * 50)
    total = sum(analysis['grade_distribution'].values())
    for grade, count in sorted(analysis['grade_distribution'].items()):
        pct = count / total * 100
        report.append(f"{grade}: {count}条 ({pct:.1f}%)")
    report.append("")
    
    # 平均得分
    report.append("【三、各指标平均得分】")
    report.append("-" * 50)
    metric_names = {
        "retrieval_precision": "检索精度",
        "retrieval_recall": "检索召回",
        "faithfulness": "事实一致性",
        "answer_relevancy": "回答相关性",
        "overall_score": "综合得分"
    }
    for metric, name in metric_names.items():
        avg = analysis['avg_scores'][metric]
        report.append(f"{name}: {avg:.3f} (范围: {analysis['score_ranges'][metric]['min']:.3f} - {analysis['score_ranges'][metric]['max']:.3f})")
    report.append("")
    
    # 场景分析
    report.append("【四、各场景评测结果】")
    report.append("-" * 50)
    for scenario in sorted(analysis['scenario_scores'].keys()):
        score = analysis['scenario_scores'][scenario]
        count = analysis['scenario_distribution'][scenario]
        report.append(f"{scenario}: 平均分 {score:.3f} ({count}条用例)")
    report.append("")
    
    # 结论
    report.append("【五、评测结论】")
    report.append("-" * 50)
    overall = analysis['avg_scores']['overall_score']
    if overall >= 0.85:
        report.append("RAG系统整体表现优秀，各项指标均达到良好以上水平。")
    elif overall >= 0.75:
        report.append("RAG系统整体表现良好，仍有提升空间。")
    elif overall >= 0.65:
        report.append("RAG系统表现合格，建议针对薄弱环节进行优化。")
    else:
        report.append("RAG系统需要较大改进，建议全面优化各模块。")
    
    report.append("")
    report.append("=" * 70)
    report.append("报告结束")
    report.append("=" * 70)
    
    # 保存报告
    report_text = "\n".join(report)
    with open(os.path.join(output_dir, "evaluation_report.txt"), "w", encoding="utf-8") as f:
        f.write(report_text)
    print("已生成: evaluation_report.txt")
    
    return report_text

def save_results_to_excel(results, analysis, output_dir):
    """保存结果到Excel"""
    df = pd.DataFrame(results)
    df.to_excel(os.path.join(output_dir, "evaluation_details.xlsx"), index=False)
    print("已生成: evaluation_details.xlsx")
    
    # 保存汇总
    summary = {
        "指标": ["检索精度", "检索召回", "事实一致性", "回答相关性", "综合得分"],
        "平均值": [
            analysis["avg_scores"]["retrieval_precision"],
            analysis["avg_scores"]["retrieval_recall"],
            analysis["avg_scores"]["faithfulness"],
            analysis["avg_scores"]["answer_relevancy"],
            analysis["avg_scores"]["overall_score"]
        ],
        "最低分": [
            analysis["score_ranges"]["retrieval_precision"]["min"],
            analysis["score_ranges"]["retrieval_recall"]["min"],
            analysis["score_ranges"]["faithfulness"]["min"],
            analysis["score_ranges"]["answer_relevancy"]["min"],
            analysis["score_ranges"]["overall_score"]["min"]
        ],
        "最高分": [
            analysis["score_ranges"]["retrieval_precision"]["max"],
            analysis["score_ranges"]["retrieval_recall"]["max"],
            analysis["score_ranges"]["faithfulness"]["max"],
            analysis["score_ranges"]["answer_relevancy"]["max"],
            analysis["score_ranges"]["overall_score"]["max"]
        ]
    }
    df_summary = pd.DataFrame(summary)
    df_summary.to_excel(os.path.join(output_dir, "evaluation_summary.xlsx"), index=False)
    print("已生成: evaluation_summary.xlsx")

def main():
    global results
    
    print("=" * 70)
    print("RAGAS 评测报告生成器")
    print("=" * 70)
    print()
    
    # 1. 加载测试数据
    print("[1/5] 加载测试数据...")
    data = load_test_data("ragas_test_data.json")
    print()
    
    # 2. 执行评测（模拟）
    print("[2/5] 执行 Ragas 评测...")
    results = simulate_ragas_evaluation(data)
    print(f"完成评测 {len(results)} 条用例")
    print()
    
    # 3. 分析结果
    print("[3/5] 分析评测结果...")
    analysis = analyze_results(results)
    print()
    
    # 4. 生成图表
    print("[4/5] 生成可视化图表...")
    generate_pie_charts(analysis, output_dir)
    generate_bar_charts(analysis, output_dir)
    print()
    
    # 5. 生成报告
    print("[5/5] 生成评测报告...")
    report_text = generate_report(analysis, results, output_dir)
    save_results_to_excel(results, analysis, output_dir)
    print()
    
    # 保存JSON格式的详细结果
    with open(os.path.join(output_dir, "evaluation_results.json"), "w", encoding="utf-8") as f:
        json.dump({"analysis": analysis, "results": results}, f, ensure_ascii=False, indent=2)
    print("已生成: evaluation_results.json")
    
    print()
    print("=" * 70)
    print("评测完成！所有文件已保存到:", os.path.abspath(output_dir))
    print("=" * 70)
    print()
    
    # 打印报告摘要
    print(report_text)

if __name__ == "__main__":
    main()
