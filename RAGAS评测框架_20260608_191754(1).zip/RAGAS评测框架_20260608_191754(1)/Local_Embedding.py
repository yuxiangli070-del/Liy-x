"""
2、封装本地Embedding模型
提供文本向量化能力，支持 OpenAI 兼容接口
"""
import os
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_core.embeddings import Embeddings

# 加载环境配置
load_dotenv()

def get_local_embeddings(
    base_url: str = None,
    api_key: str = None,
    model_name: str = None
) -> Embeddings:
    """
    获取本地 Embedding 实例
    
    Args:
        base_url: Embedding 服务地址
        api_key: API 密钥
        model_name: 模型名称
    
    Returns:
        Embeddings: LangChain 兼容的嵌入模型
    """
    # 使用环境变量或默认值
    base_url = base_url or os.getenv("LOCAL_EMB_BASE_URL", "http://192.168.1.249")
    api_key = api_key or os.getenv("LOCAL_EMB_API_KEY", "dummy_key")
    model_name = model_name or os.getenv("LOCAL_EMB_MODEL_NAME", "bge-m3")
    
    try:
        embeddings = OpenAIEmbeddings(
            base_url=base_url,
            api_key=api_key,
            model=model_name,
            timeout=60
        )
        print(f"✅ 本地Embedding加载成功: {model_name}")
        return embeddings
    except Exception as e:
        print(f"❌ 本地Embedding加载失败: {str(e)}")
        raise

# 创建全局实例
local_embeddings = get_local_embeddings()
