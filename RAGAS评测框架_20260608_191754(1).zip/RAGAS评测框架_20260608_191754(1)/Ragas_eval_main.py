"""
4、Ragas 离线评测主程序（核心）
整合「本地 DeepSeek LLM + 本地 Embedding + Dify 数据集」，执行全维度评测。

支持的评测指标（RAG 四大核心维度）：
<1> retrieval_precision：检索精度（知识库召回质量）
<2> retrieval_recall：检索召回率
<3> faithfulness：事实一致性（回答是否忠于检索上下文，幻觉检测）
<4> answer_relevancy：回答相关性（回答是否贴合用户问题）

功能特性：
- 支持环境变量配置
- 自动加载 Dify 数据集
- 全流程使用本地模型，数据不出域
- 生成详细评测报告
- 支持自定义测试问题
"""
import os
import json
import time
from typing import List, Dict, Any

import pandas as pd
from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    retrieval_precision,
    retrieval_recall
)
from datasets import Dataset
from dotenv import load_dotenv

# 导入本地模型封装
from Local_LLM import local_deepseek_llm
from Local_Embedding import local_embeddings
from Get_Dify_Rag_Data import generate_rag_dataset, DEFAULT_TEST_QUESTIONS

# 加载环境配置
load_dotenv()

def run_ragas_evaluation(
    dataset: List[Dict[str, Any]],
    metrics: List = None,
    output_path: str = None
) -> dict:
    """
    执行 Ragas 离线评测
    
    Args:
        dataset: RAG 评测数据集
        metrics: 评测指标列表
        output_path: 报告输出路径
    
    Returns:
        dict: 评测结果摘要
    """
    # 默认评测指标
    if metrics is None:
        metrics = [
            retrieval_precision,
            retrieval_recall,
            faithfulness,
            answer_relevancy
        ]
    
    # 默认输出路径
    if output_path is None:
        output_path = os.getenv("EVAL_OUTPUT_PATH", "./ragas_report.csv")
    
    print("\n" + "="*70)
    print("🚀 开始 Ragas 离线评测")
    print("="*70)
    print(f"📊 评测样本数: {len(dataset)}")
    print(f"📈 评测指标: {[m.name for m in metrics]}")
    print(f"🤖 LLM: {local_deepseek_llm.model_name}")
    print(f"🔍 Embedding: {local_embeddings.model}")
    print("="*70)
    
    start_time = time.time()
    
    try:
        # 转为 HuggingFace Dataset 格式（Ragas 标准输入）
        hf_dataset = Dataset.from_list(dataset)
        
        # 执行离线评测（全程使用本地DeepSeek + 本地Embedding）
        result = evaluate(
            dataset=hf_dataset,
            metrics=metrics,
            llm=local_deepseek_llm,       # 打分LLM：本地DeepSeek-7B
            embeddings=local_embeddings,   # 语义向量：本地Embedding模型
            verbose=True
        )
        
        elapsed_time = time.time() - start_time
        
        # 输出结果
        print("\n" + "="*70)
        print("✅ Ragas 离线评测完成")
        print("="*70)
        print(f"⏱️  耗时: {elapsed_time:.2f} 秒")
        print("\n📋 评测结果摘要:")
        print(result)
        
        # 转为DataFrame查看每条样本分数
        df = result.to_pandas()
        
        print("\n📝 每条样本详细分数:")
        print(df[['question', 'retrieval_precision', 'retrieval_recall', 
                  'faithfulness', 'answer_relevancy']])
        
        # 保存评测报告到CSV
        df.to_csv(output_path, index=False, encoding="utf-8-sig")
        print(f"\n📄 评测报告已保存至: {output_path}")
        
        # 保存完整结果到 JSON
        result_json_path = output_path.replace(".csv", ".json")
        with open(result_json_path, "w", encoding="utf-8") as f:
            json.dump({
                "summary": {k: float(v) for k, v in result.items()},
                "details": df.to_dict(orient="records"),
                "metadata": {
                    "total_samples": len(dataset),
                    "metrics": [m.name for m in metrics],
                    "llm": local_deepseek_llm.model_name,
                    "embedding": local_embeddings.model,
                    "elapsed_time": elapsed_time
                }
            }, f, ensure_ascii=False, indent=2)
        print(f"📊 完整结果已保存至: {result_json_path}")
        
        return {
            "success": True,
            "summary": {k: float(v) for k, v in result.items()},
            "total_samples": len(dataset),
            "elapsed_time": elapsed_time,
            "output_files": [output_path, result_json_path]
        }
        
    except Exception as e:
        print(f"\n❌ 评测失败: {str(e)}")
        return {
            "success": False,
            "error": str(e)
        }

def load_local_dataset(file_path: str) -> List[Dict[str, Any]]:
    """
    从本地 JSON 文件加载评测数据集
    
    Args:
        file_path: JSON 文件路径
    
    Returns:
        list: RAG 评测数据集
    """
    if not os.path.exists(file_path):
        print(f"⚠️ 本地数据集文件不存在: {file_path}")
        return None
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            dataset = json.load(f)
        print(f"✅ 从本地加载数据集: {len(dataset)} 条记录")
        return dataset
    except Exception as e:
        print(f"❌ 加载本地数据集失败: {str(e)}")
        return None

def main():
    """
    主函数：执行完整的 RAG 评测流程
    """
    print("\n" + "="*70)
    print("🎯 RAGAS 评测框架 v1.0")
    print("="*70)
    
    # 尝试从本地加载数据集
    local_dataset = load_local_dataset("rag_dataset.json")
    
    if local_dataset:
        # 使用本地数据集
        print("\n📥 使用本地数据集")
        rag_dataset = local_dataset
    else:
        # 从 Dify 获取数据
        print("\n🌐 从 Dify 获取评测数据")
        try:
            rag_dataset = generate_rag_dataset(DEFAULT_TEST_QUESTIONS)
        except ValueError as e:
            print(f"⚠️ {e}")
            print("📝 使用内置测试数据进行演示")
            # 创建模拟数据用于演示
            rag_dataset = [
                {
                    "question": "请介绍项目背景",
                    "contexts": ["这是一个基于大语言模型的智能问答系统，旨在提供高质量的问答服务。"],
                    "answer": "本项目是一个基于大语言模型的智能问答系统，旨在为用户提供准确、高效的问答服务。"
                },
                {
                    "question": "DeepSeek模型有哪些特点",
                    "contexts": ["DeepSeek模型具有高性能、低延迟、支持多轮对话等特点。"],
                    "answer": "DeepSeek模型具有高性能推理能力，响应速度快，支持复杂的多轮对话场景。"
                }
            ]
    
    # 执行评测
    if rag_dataset:
        result = run_ragas_evaluation(rag_dataset)
        
        if result["success"]:
            print("\n🎉 评测流程全部完成！")
        else:
            print("\n😢 评测流程失败，请检查日志。")
    else:
        print("❌ 没有可用的评测数据")

if __name__ == "__main__":
    main()
