"""
1、实现自定义本地LLM
封装本地大语言模型，提供 OpenAI 兼容接口
支持配置加载和错误处理
"""
import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.language_models import BaseChatModel

# 加载环境配置
load_dotenv()

def get_local_llm(
    base_url: str = None,
    model_name: str = None,
    api_key: str = None,
    temperature: float = None,
    max_tokens: int = None
) -> BaseChatModel:
    """
    获取本地 LLM 实例
    
    Args:
        base_url: LLM 服务地址
        model_name: 模型名称
        api_key: API 密钥（本地模型通常不需要）
        temperature: 温度参数，越低越稳定
        max_tokens: 最大生成token数
    
    Returns:
        BaseChatModel: LangChain 兼容的聊天模型
    """
    # 使用环境变量或默认值
    base_url = base_url or os.getenv("LOCAL_LLM_BASE_URL", "http://192.168.1.249")
    model_name = model_name or os.getenv("LOCAL_LLM_MODEL_NAME", "deepseek-7b-chat")
    api_key = api_key or os.getenv("LOCAL_LLM_API_KEY", "dummy_key")
    temperature = temperature if temperature is not None else float(os.getenv("LOCAL_LLM_TEMPERATURE", "0.1"))
    max_tokens = max_tokens if max_tokens is not None else int(os.getenv("LOCAL_LLM_MAX_TOKENS", "1024"))
    
    try:
        llm = ChatOpenAI(
            base_url=base_url,
            model=model_name,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=60
        )
        print(f"✅ 本地LLM加载成功: {model_name}")
        return llm
    except Exception as e:
        print(f"❌ 本地LLM加载失败: {str(e)}")
        raise

# 创建全局实例
local_deepseek_llm = get_local_llm()
