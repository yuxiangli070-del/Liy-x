"""
将评测数据整理成表格并保存到桌面
"""
import json
import pandas as pd
from datetime import datetime
import os

def load_evaluation_results():
    """加载评测结果"""
    results_file = "evaluation_results/evaluation_results.json"
    with open(results_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data["results"], data["analysis"]

def create_comprehensive_table(results, analysis):
    """创建综合评测表格"""
    
    # 1. 详细评测结果表
    df_details = pd.DataFrame(results)
    
    # 重新排列列顺序
    columns_order = [
        "question", "scenario", "grade", "overall_score",
        "retrieval_precision", "retrieval_recall", "faithfulness", "answer_relevancy",
        "context_precision", "context_recall"
    ]
    
    # 确保所有列都存在
    available_columns = [col for col in columns_order if col in df_details.columns]
    df_details = df_details[available_columns]
    
    # 重命名列
    column_names = {
        "question": "问题",
        "scenario": "场景",
        "grade": "等级",
        "overall_score": "综合得分",
        "retrieval_precision": "检索精度",
        "retrieval_recall": "检索召回",
        "faithfulness": "事实一致性",
        "answer_relevancy": "回答相关性",
        "context_precision": "上下文精度",
        "context_recall": "上下文召回"
    }
    df_details = df_details.rename(columns=column_names)
    
    # 2. 汇总统计表
    summary_data = {
        "指标": ["检索精度", "检索召回", "事实一致性", "回答相关性", "综合得分"],
        "平均值": [
            analysis["avg_scores"]["retrieval_precision"],
            analysis["avg_scores"]["retrieval_recall"],
            analysis["avg_scores"]["faithfulness"],
            analysis["avg_scores"]["answer_relevancy"],
            analysis["avg_scores"]["overall_score"]
        ],
        "最低分": [
            analysis["score_ranges"]["retrieval_precision"]["min"],
            analysis["score_ranges"]["retrieval_recall"]["min"],
            analysis["score_ranges"]["faithfulness"]["min"],
            analysis["score_ranges"]["answer_relevancy"]["min"],
            analysis["score_ranges"]["overall_score"]["min"]
        ],
        "最高分": [
            analysis["score_ranges"]["retrieval_precision"]["max"],
            analysis["score_ranges"]["retrieval_recall"]["max"],
            analysis["score_ranges"]["faithfulness"]["max"],
            analysis["score_ranges"]["answer_relevancy"]["max"],
            analysis["score_ranges"]["overall_score"]["max"]
        ],
        "标准差": [
            analysis["score_ranges"]["retrieval_precision"]["std"],
            analysis["score_ranges"]["retrieval_recall"]["std"],
            analysis["score_ranges"]["faithfulness"]["std"],
            analysis["score_ranges"]["answer_relevancy"]["std"],
            analysis["score_ranges"]["overall_score"]["std"]
        ]
    }
    df_summary = pd.DataFrame(summary_data)
    
    # 3. 等级分布表
    grade_data = {
        "等级": list(analysis["grade_distribution"].keys()),
        "用例数量": list(analysis["grade_distribution"].values()),
        "占比": [f"{count/sum(analysis['grade_distribution'].values())*100:.1f}%" 
                for count in analysis["grade_distribution"].values()]
    }
    df_grades = pd.DataFrame(grade_data)
    
    # 4. 场景分析表
    scenario_data = {
        "场景": list(analysis["scenario_scores"].keys()),
        "平均得分": list(analysis["scenario_scores"].values()),
        "用例数量": [analysis["scenario_distribution"][s] for s in analysis["scenario_scores"].keys()]
    }
    df_scenarios = pd.DataFrame(scenario_data)
    df_scenarios = df_scenarios.sort_values("平均得分", ascending=False)
    
    return df_details, df_summary, df_grades, df_scenarios

def save_to_desktop(df_details, df_summary, df_grades, df_scenarios):
    """保存表格到桌面"""
    
    # 获取桌面路径
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    if not os.path.exists(desktop_path):
        desktop_path = r"C:\Users\Administrator\Desktop"
    
    # 生成文件名（带时间戳）
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 保存详细结果
    details_file = os.path.join(desktop_path, f"RAG评测详细结果_{timestamp}.xlsx")
    with pd.ExcelWriter(details_file, engine='openpyxl') as writer:
        df_details.to_excel(writer, sheet_name='详细评测结果', index=False)
        df_summary.to_excel(writer, sheet_name='汇总统计', index=False)
        df_grades.to_excel(writer, sheet_name='等级分布', index=False)
        df_scenarios.to_excel(writer, sheet_name='场景分析', index=False)
    
    print(f"✅ 已保存综合表格到: {details_file}")
    return details_file

def main():
    print("=" * 70)
    print("将评测数据整理成表格并保存到桌面")
    print("=" * 70)
    print()
    
    # 1. 加载评测结果
    print("[1/3] 加载评测结果...")
    results, analysis = load_evaluation_results()
    print(f"   加载了 {len(results)} 条评测记录")
    print()
    
    # 2. 创建表格
    print("[2/3] 创建表格...")
    df_details, df_summary, df_grades, df_scenarios = create_comprehensive_table(results, analysis)
    print(f"   详细结果表: {len(df_details)} 行 × {len(df_details.columns)} 列")
    print(f"   汇总统计表: {len(df_summary)} 行 × {len(df_summary.columns)} 列")
    print(f"   等级分布表: {len(df_grades)} 行 × {len(df_grades.columns)} 列")
    print(f"   场景分析表: {len(df_scenarios)} 行 × {len(df_scenarios.columns)} 列")
    print()
    
    # 3. 保存到桌面
    print("[3/3] 保存到桌面...")
    file_path = save_to_desktop(df_details, df_summary, df_grades, df_scenarios)
    print()
    
    # 显示表格预览
    print("=" * 70)
    print("表格预览")
    print("=" * 70)
    print()
    
    print("【详细评测结果】(前5条)")
    print(df_details.head().to_string(index=False))
    print()
    
    print("【汇总统计】")
    print(df_summary.to_string(index=False))
    print()
    
    print("【等级分布】")
    print(df_grades.to_string(index=False))
    print()
    
    print("【场景分析】")
    print(df_scenarios.to_string(index=False))
    print()
    
    print("=" * 70)
    print(f"完成！表格已保存到桌面: {os.path.basename(file_path)}")
    print("=" * 70)

if __name__ == "__main__":
    main()