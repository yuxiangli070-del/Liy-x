"""
项目打包脚本
将核心文件打包并保存到桌面
"""
import os
import zipfile
from datetime import datetime

def get_core_files():
    """定义需要打包的核心文件列表"""
    core_files = [
        # 核心评测框架
        "Ragas_eval_main.py",
        "Local_LLM.py",
        "Local_Embedding.py",
        "Get_Dify_Rag_Data.py",
        
        # 工具模块
        "excel_utils.py",
        
        # 测试数据生成器
        "generate_test_data_simple.py",
        
        # 评测报告生成器
        "ragas_evaluation_with_report.py",
        "run_evaluation_to_desktop.py",
        "run_evaluation_with_process.py",
        
        # 配置文件
        "requirements.txt",
        ".env",
        
        # 辅助脚本
        "save_evaluation_to_desktop.py",
        "package_project.py"
    ]
    
    return core_files

def package_project():
    """执行打包操作"""
    # 获取桌面路径
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    if not os.path.exists(desktop_path):
        desktop_path = r"C:\Users\Administrator\Desktop"
    
    # 生成打包文件名（带时间戳）
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"RAGAS评测框架_{timestamp}.zip"
    zip_path = os.path.join(desktop_path, zip_filename)
    
    # 获取核心文件列表
    core_files = get_core_files()
    
    print("=" * 70)
    print("项目打包工具")
    print("=" * 70)
    print()
    
    # 检查文件是否存在
    existing_files = []
    missing_files = []
    
    for file in core_files:
        if os.path.exists(file):
            existing_files.append(file)
            print("[OK] " + file)
        else:
            missing_files.append(file)
            print("[--] " + file + " (不存在)")
    
    print()
    
    if missing_files:
        print(f"注意：{len(missing_files)} 个文件不存在，将跳过")
        print(f"缺失文件: {', '.join(missing_files)}")
        print()
    
    # 创建ZIP文件
    print(f"正在创建压缩包: {zip_filename}")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file in existing_files:
            zipf.write(file, file)
            print(f"  添加: {file}")
    
    # 获取压缩包大小
    zip_size = os.path.getsize(zip_path)
    zip_size_mb = zip_size / (1024 * 1024)
    
    print()
    print("=" * 70)
    print("打包完成！")
    print("=" * 70)
    print(f"📦 打包文件: {zip_path}")
    print(f"📊 文件数量: {len(existing_files)} 个")
    print(f"💾 文件大小: {zip_size_mb:.2f} MB")
    print(f"⏱️ 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    return zip_path

if __name__ == "__main__":
    package_project()