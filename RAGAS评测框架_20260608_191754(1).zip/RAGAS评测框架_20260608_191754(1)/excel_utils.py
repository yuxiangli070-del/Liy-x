"""
Excel 通用工具模块
提供各类 Excel 文件读取、处理、写入的通用函数

功能特性：
- 支持 .xls 和 .xlsx 格式
- 支持读取指定 Sheet
- 支持按行/按列读取
- 支持数据类型转换
- 支持批量读取多个文件
- 支持写入 Excel 文件
"""
import os
from typing import List, Dict, Any, Union, Optional
import pandas as pd
from pandas import DataFrame

def read_excel_file(
    file_path: str,
    sheet_name: Union[str, int] = 0,
    header: int = 0,
    skiprows: int = 0,
    usecols: Optional[List[int]] = None,
    dtype: Optional[Dict[str, Any]] = None,
    parse_dates: Optional[List[str]] = None,
    na_values: Optional[List[str]] = None
) -> DataFrame:
    """
    读取 Excel 文件的指定 Sheet
    
    Args:
        file_path: Excel 文件路径
        sheet_name: Sheet 名称或索引，默认为第一个 Sheet
        header: 表头行索引，默认为第 0 行
        skiprows: 跳过的行数
        usecols: 指定读取的列索引列表
        dtype: 列数据类型字典
        parse_dates: 需要解析为日期的列名列表
        na_values: 视为空值的字符串列表
    
    Returns:
        DataFrame: 包含 Excel 数据的 DataFrame
    
    Raises:
        FileNotFoundError: 文件不存在
        ValueError: 文件格式不正确
    """
    # 检查文件是否存在
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    # 检查文件格式
    ext = os.path.splitext(file_path)[1].lower()
    if ext not in ['.xls', '.xlsx']:
        raise ValueError(f"不支持的文件格式: {ext}，仅支持 .xls 和 .xlsx")
    
    try:
        df = pd.read_excel(
            file_path,
            sheet_name=sheet_name,
            header=header,
            skiprows=skiprows,
            usecols=usecols,
            dtype=dtype,
            parse_dates=parse_dates,
            na_values=na_values,
            engine='openpyxl' if ext == '.xlsx' else 'xlrd'
        )
        print(f"✅ 成功读取 Excel 文件: {file_path}")
        print(f"   行数: {len(df)}, 列数: {len(df.columns)}")
        return df
    except Exception as e:
        raise RuntimeError(f"读取 Excel 文件失败: {str(e)}")

def read_excel_all_sheets(file_path: str) -> Dict[str, DataFrame]:
    """
    读取 Excel 文件的所有 Sheet
    
    Args:
        file_path: Excel 文件路径
    
    Returns:
        Dict[str, DataFrame]: 键为 Sheet 名称，值为对应的数据
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    try:
        xls = pd.ExcelFile(file_path)
        sheets = {sheet: xls.parse(sheet) for sheet in xls.sheet_names}
        print(f"✅ 成功读取 Excel 文件的所有 Sheet: {file_path}")
        print(f"   Sheet 数量: {len(sheets)}")
        for sheet_name, df in sheets.items():
            print(f"   - {sheet_name}: {len(df)} 行, {len(df.columns)} 列")
        return sheets
    except Exception as e:
        raise RuntimeError(f"读取 Excel 文件失败: {str(e)}")

def read_excel_to_dict(
    file_path: str,
    sheet_name: Union[str, int] = 0,
    key_col: int = 0,
    value_col: Optional[int] = None,
    header: int = 0
) -> Dict[Any, Any]:
    """
    将 Excel 数据读取为字典
    
    Args:
        file_path: Excel 文件路径
        sheet_name: Sheet 名称或索引
        key_col: 作为键的列索引
        value_col: 作为值的列索引，None 表示返回整行数据
        header: 表头行索引
    
    Returns:
        Dict[Any, Any]: 字典形式的数据
    """
    df = read_excel_file(file_path, sheet_name=sheet_name, header=header)
    
    if key_col >= len(df.columns):
        raise ValueError(f"键列索引 {key_col} 超出范围")
    
    key_name = df.columns[key_col]
    
    if value_col is None:
        # 返回整行数据作为值
        result = df.set_index(key_name).to_dict('index')
    else:
        if value_col >= len(df.columns):
            raise ValueError(f"值列索引 {value_col} 超出范围")
        value_name = df.columns[value_col]
        result = df.set_index(key_name)[value_name].to_dict()
    
    print(f"✅ 成功转换为字典，共 {len(result)} 条记录")
    return result

def read_excel_to_list(
    file_path: str,
    sheet_name: Union[str, int] = 0,
    header: int = 0,
    as_dict: bool = True
) -> List[Union[Dict[str, Any], List[Any]]]:
    """
    将 Excel 数据读取为列表
    
    Args:
        file_path: Excel 文件路径
        sheet_name: Sheet 名称或索引
        header: 表头行索引
        as_dict: 是否返回字典列表，False 返回列表列表
    
    Returns:
        List: 列表形式的数据
    """
    df = read_excel_file(file_path, sheet_name=sheet_name, header=header)
    
    if as_dict:
        result = df.to_dict('records')
    else:
        result = df.values.tolist()
    
    print(f"✅ 成功转换为列表，共 {len(result)} 条记录")
    return result

def read_excel_columns(
    file_path: str,
    sheet_name: Union[str, int] = 0,
    columns: Union[List[str], List[int]] = None,
    header: int = 0
) -> DataFrame:
    """
    读取 Excel 的指定列
    
    Args:
        file_path: Excel 文件路径
        sheet_name: Sheet 名称或索引
        columns: 列名列表或列索引列表
        header: 表头行索引
    
    Returns:
        DataFrame: 包含指定列的数据
    """
    df = read_excel_file(file_path, sheet_name=sheet_name, header=header)
    
    if columns is None:
        return df
    
    # 处理列索引
    if all(isinstance(c, int) for c in columns):
        columns = [df.columns[c] for c in columns]
    
    # 验证列名
    invalid_cols = [col for col in columns if col not in df.columns]
    if invalid_cols:
        raise ValueError(f"不存在的列名: {invalid_cols}")
    
    result = df[columns]
    print(f"✅ 成功读取指定列: {columns}")
    return result

def read_excel_rows(
    file_path: str,
    sheet_name: Union[str, int] = 0,
    start_row: int = 0,
    end_row: Optional[int] = None,
    header: int = 0
) -> DataFrame:
    """
    读取 Excel 的指定行范围
    
    Args:
        file_path: Excel 文件路径
        sheet_name: Sheet 名称或索引
        start_row: 起始行索引（不包含表头）
        end_row: 结束行索引（不包含），None 表示到末尾
        header: 表头行索引
    
    Returns:
        DataFrame: 包含指定行范围的数据
    """
    df = read_excel_file(file_path, sheet_name=sheet_name, header=header)
    
    if end_row is None:
        end_row = len(df)
    
    if start_row < 0 or end_row > len(df):
        raise ValueError(f"行范围超出数据范围")
    
    result = df.iloc[start_row:end_row]
    print(f"✅ 成功读取行范围 [{start_row}:{end_row}]")
    return result

def read_multiple_excel(
    file_paths: List[str],
    sheet_name: Union[str, int] = 0,
    concat: bool = False
) -> Union[List[DataFrame], DataFrame]:
    """
    批量读取多个 Excel 文件
    
    Args:
        file_paths: Excel 文件路径列表
        sheet_name: Sheet 名称或索引
        concat: 是否合并为一个 DataFrame
    
    Returns:
        List[DataFrame] 或 DataFrame: 读取的数据
    """
    dfs = []
    for file_path in file_paths:
        try:
            df = read_excel_file(file_path, sheet_name=sheet_name)
            df['source_file'] = os.path.basename(file_path)  # 添加来源文件列
            dfs.append(df)
        except Exception as e:
            print(f"⚠️ 读取文件失败 {file_path}: {str(e)}")
    
    if concat and dfs:
        result = pd.concat(dfs, ignore_index=True)
        print(f"✅ 成功合并 {len(dfs)} 个文件，共 {len(result)} 行")
        return result
    
    return dfs

def write_excel_file(
    data: Union[DataFrame, List[Dict[str, Any]]],
    file_path: str,
    sheet_name: str = 'Sheet1',
    index: bool = False,
    header: bool = True,
    encoding: str = 'utf-8-sig'
) -> None:
    """
    将数据写入 Excel 文件
    
    Args:
        data: DataFrame 或字典列表
        file_path: 输出文件路径
        sheet_name: Sheet 名称
        index: 是否写入索引列
        header: 是否写入表头
        encoding: 文件编码
    """
    # 转换为 DataFrame
    if isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = data
    
    # 检查输出目录
    output_dir = os.path.dirname(file_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    
    # 写入 Excel
    try:
        df.to_excel(
            file_path,
            sheet_name=sheet_name,
            index=index,
            header=header,
            encoding=encoding,
            engine='openpyxl'
        )
        print(f"✅ 成功写入 Excel 文件: {file_path}")
        print(f"   行数: {len(df)}, 列数: {len(df.columns)}")
    except Exception as e:
        raise RuntimeError(f"写入 Excel 文件失败: {str(e)}")

def write_excel_multiple_sheets(
    data_dict: Dict[str, Union[DataFrame, List[Dict[str, Any]]]],
    file_path: str,
    index: bool = False
) -> None:
    """
    将多个数据集写入 Excel 的不同 Sheet
    
    Args:
        data_dict: 键为 Sheet 名称，值为数据（DataFrame 或字典列表）
        file_path: 输出文件路径
        index: 是否写入索引列
    """
    # 检查输出目录
    output_dir = os.path.dirname(file_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    
    try:
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            for sheet_name, data in data_dict.items():
                if isinstance(data, list):
                    df = pd.DataFrame(data)
                else:
                    df = data
                df.to_excel(writer, sheet_name=sheet_name, index=index)
        
        print(f"✅ 成功写入 Excel 文件: {file_path}")
        print(f"   Sheet 数量: {len(data_dict)}")
        for sheet_name, data in data_dict.items():
            df = pd.DataFrame(data) if isinstance(data, list) else data
            print(f"   - {sheet_name}: {len(df)} 行")
    except Exception as e:
        raise RuntimeError(f"写入 Excel 文件失败: {str(e)}")

def get_excel_sheet_names(file_path: str) -> List[str]:
    """
    获取 Excel 文件的所有 Sheet 名称
    
    Args:
        file_path: Excel 文件路径
    
    Returns:
        List[str]: Sheet 名称列表
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    try:
        xls = pd.ExcelFile(file_path)
        return xls.sheet_names
    except Exception as e:
        raise RuntimeError(f"读取 Sheet 名称失败: {str(e)}")

def get_excel_info(file_path: str) -> Dict[str, Any]:
    """
    获取 Excel 文件的基本信息
    
    Args:
        file_path: Excel 文件路径
    
    Returns:
        Dict[str, Any]: 文件信息字典
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    try:
        xls = pd.ExcelFile(file_path)
        info = {
            'file_path': file_path,
            'file_size': os.path.getsize(file_path),
            'sheet_count': len(xls.sheet_names),
            'sheet_names': xls.sheet_names,
            'sheets': {}
        }
        
        for sheet_name in xls.sheet_names:
            df = xls.parse(sheet_name)
            info['sheets'][sheet_name] = {
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': list(df.columns)
            }
        
        return info
    except Exception as e:
        raise RuntimeError(f"获取 Excel 信息失败: {str(e)}")

# ------------------- 示例用法 -------------------
if __name__ == "__main__":
    # 示例文件路径（实际使用时替换为真实路径）
    sample_file = "sample.xlsx"
    
    # 1. 读取整个 Sheet
    # df = read_excel_file(sample_file)
    
    # 2. 读取所有 Sheet
    # sheets = read_excel_all_sheets(sample_file)
    
    # 3. 读取为字典
    # data_dict = read_excel_to_dict(sample_file, key_col=0)
    
    # 4. 读取为列表
    # data_list = read_excel_to_list(sample_file)
    
    # 5. 读取指定列
    # df = read_excel_columns(sample_file, columns=['姓名', '年龄'])
    
    # 6. 读取指定行范围
    # df = read_excel_rows(sample_file, start_row=0, end_row=10)
    
    # 7. 批量读取多个文件
    # dfs = read_multiple_excel(['file1.xlsx', 'file2.xlsx'])
    
    # 8. 写入 Excel
    # write_excel_file(df, 'output.xlsx')
    
    # 9. 获取文件信息
    # info = get_excel_info(sample_file)
    # print(json.dumps(info, ensure_ascii=False, indent=2))
    
    print("📚 Excel 工具模块加载完成")
    print("可用函数:")
    print("  - read_excel_file: 读取 Excel 文件")
    print("  - read_excel_all_sheets: 读取所有 Sheet")
    print("  - read_excel_to_dict: 读取为字典")
    print("  - read_excel_to_list: 读取为列表")
    print("  - read_excel_columns: 读取指定列")
    print("  - read_excel_rows: 读取指定行范围")
    print("  - read_multiple_excel: 批量读取")
    print("  - write_excel_file: 写入 Excel")
    print("  - write_excel_multiple_sheets: 写入多 Sheet")
    print("  - get_excel_sheet_names: 获取 Sheet 名称")
    print("  - get_excel_info: 获取文件信息")
